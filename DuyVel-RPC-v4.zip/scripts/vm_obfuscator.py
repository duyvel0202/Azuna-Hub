import os
import random
import secrets

STRINGS = {
    0: "962990036020756480",
    1: "wss://gateway.discord.gg/?v=10&encoding=json",
    2: "https://discord.com/api/v9/applications/",
    3: "/external-assets",
    4: "https://discord.com/api/v10/invites/",
    5: "?with_counts=true",
    6: "https://cdn.discordapp.com/icons/",
    7: "https://cdn.discordapp.com/avatars/",
    8: "https://cdn.discordapp.com/embed/avatars/0.png",
    9: "hxmoon",
    10: "https://discord.gg/hxmoon",
    11: "discord://-/invite/hxmoon",
    12: "https://valorant-api.com/v1/agents?isPlayableCharacter=true",
    13: "https://valorant-api.com/v1/maps",
    14: "https://valorant-api.com/v1/competitivetiers",
    15: "https://apis.roblox.com/universes/v1/places/",
    16: "/universe",
    17: "https://games.roblox.com/v1/games?universeIds=",
    18: "https://thumbnails.roblox.com/v1/games/icons?universeIds=",
    19: "&returnPolicy=PlaceHolder&size=512x512&format=Png&isCircular=false",
    20: "https://soundcloud.com/oembed?format=json&url=",
    21: "https://open.spotify.com/oembed?url=",
    22: "https://www.youtube.com/oembed?format=json&url=",
    23: "https://itunes.apple.com/search?term=",
    24: "&media=music&limit=1",
    25: "https://www.last.fm/user/",
    26: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    27: "Discord Client",
    28: "DuyVel",
    29: "Authorization",
    30: "Content-Type",
    31: "application/json",
    32: "duyvel_accounts_v4",
    33: "frida",
    34: "xposed",
    35: "substrate",
    36: "gum-js-loop",
    37: "magisk",
    38: "x64dbg",
    39: "ida64",
    40: "ollydbg",
    41: "cheatengine",
    42: "processhacker",
    43: "dnspy",
    44: "ghidra",
    45: "/proc/self/maps",
    46: "/proc/self/status",
    47: "TracerPid:",
}

def rol8(v, r):
    r &= 7
    return ((v << r) | (v >> (8 - r))) & 0xFF

def ror8(v, r):
    r &= 7
    return ((v >> r) | (v << (8 - r))) & 0xFF

def build_vm_vault(output_path):
    rng = random.SystemRandom()
    master_key = [secrets.randbelow(256) for _ in range(32)]
    sbox = list(range(256))
    rng.shuffle(sbox)
    inv_sbox = [0] * 256
    for i, v in enumerate(sbox):
        inv_sbox[v] = i

    op_pool = list(range(0x11, 0xEE))
    rng.shuffle(op_pool)
    OP_XOR = op_pool[0]
    OP_SUB = op_pool[1]
    OP_ROR = op_pool[2]
    OP_SBOX = op_pool[3]
    OP_NOP1 = op_pool[4]
    OP_NOP2 = op_pool[5]
    OP_HALT = op_pool[6]

    salt = secrets.randbelow(251) + 3
    compiled_entries = {}

    for idx, text in STRINGS.items():
        raw = text.encode("utf-8")
        prog = []
        for pos, b in enumerate(raw):
            k1 = master_key[(pos + idx * 7) % 32]
            k2 = (pos * 13 + idx * 29 + salt) & 0xFF
            rot = ((pos + idx) % 5) + 1
            x = b
            x = sbox[x]
            x = rol8(x, rot)
            x = (x + k2) & 0xFF
            x = x ^ k1

            if rng.random() < 0.35:
                prog.extend([OP_NOP1, rng.randrange(256)])
            prog.extend([
                OP_XOR, x, k1,
                OP_SUB, k2,
                OP_ROR, rot,
                OP_SBOX,
            ])
            if rng.random() < 0.25:
                prog.extend([OP_NOP2, rng.randrange(256), rng.randrange(256)])
        prog.append(OP_HALT)
        compiled_entries[idx] = prog

    def fmt_list(arr):
        return "[" + ",".join(str(x) for x in arr) + "]"

    lines = [
        "import 'dart:convert';",
        "import 'dart:typed_data';",
        "",
        "class VmVault {",
        "  static int _poison = 0;",
        f"  static final Uint8List _inv = Uint8List.fromList({fmt_list(inv_sbox)});",
        "  static final Map<int, String> _cache = <int, String>{};",
        "  static final Map<int, Uint8List> _bc = <int, Uint8List>{",
    ]
    for idx in sorted(compiled_entries.keys()):
        lines.append(f"    {idx}: Uint8List.fromList({fmt_list(compiled_entries[idx])}),")
    lines.extend([
        "  };",
        "",
        "  static void corrupt() {",
        "    _poison = 0x5A;",
        "    _cache.clear();",
        "  }",
        "",
        "  static int _ror8(int v, int r) {",
        "    final s = r & 7;",
        "    return ((v >> s) | ((v << (8 - s)) & 0xFF)) & 0xFF;",
        "  }",
        "",
        "  static String s(int id) {",
        "    if (_poison == 0 && _cache.containsKey(id)) {",
        "      return _cache[id]!;",
        "    }",
        "    final code = _bc[id];",
        "    if (code == null) return '';",
        "    final out = <int>[];",
        "    int ip = 0;",
        "    int acc = 0;",
        "    int guard = (id * 31 + 17) & 0xFF;",
        "    while (ip < code.length) {",
        "      final op = code[ip++];",
        f"      if (op == {OP_HALT}) {{",
        "        break;",
        f"      }} else if (op == {OP_XOR}) {{",
        "        final v = code[ip++];",
        "        final k = code[ip++];",
        "        acc = (v ^ k ^ _poison) & 0xFF;",
        f"      }} else if (op == {OP_SUB}) {{",
        "        final k = code[ip++];",
        "        acc = (acc - k) & 0xFF;",
        f"      }} else if (op == {OP_ROR}) {{",
        "        final r = code[ip++];",
        "        acc = _ror8(acc, r);",
        f"      }} else if (op == {OP_SBOX}) {{",
        "        acc = _inv[acc];",
        "        out.add(acc);",
        f"      }} else if (op == {OP_NOP1}) {{",
        "        guard = (guard ^ code[ip++]) & 0xFF;",
        f"      }} else if (op == {OP_NOP2}) {{",
        "        guard = (guard + code[ip++] + code[ip++]) & 0xFF;",
        "      } else {",
        "        break;",
        "      }",
        "    }",
        "    if (guard < 0) return '';",
        "    final decoded = utf8.decode(out, allowMalformed: true);",
        "    if (_poison == 0) {",
        "      _cache[id] = decoded;",
        "    }",
        "    return decoded;",
        "  }",
        "}",
        "",
    ])

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    for idx, expected in STRINGS.items():
        code = compiled_entries[idx]
        out = []
        ip = 0
        acc = 0
        while ip < len(code):
            op = code[ip]
            ip += 1
            if op == OP_HALT:
                break
            elif op == OP_XOR:
                v = code[ip]
                k = code[ip + 1]
                ip += 2
                acc = (v ^ k) & 0xFF
            elif op == OP_SUB:
                k = code[ip]
                ip += 1
                acc = (acc - k) & 0xFF
            elif op == OP_ROR:
                r = code[ip]
                ip += 1
                acc = ror8(acc, r)
            elif op == OP_SBOX:
                acc = inv_sbox[acc]
                out.append(acc)
            elif op == OP_NOP1:
                ip += 1
            elif op == OP_NOP2:
                ip += 2
        actual = bytes(out).decode("utf-8")
        assert actual == expected, f"VM mismatch on id {idx}"

if __name__ == "__main__":
    build_vm_vault(os.path.join("lib", "security", "vm_vault.dart"))
    print("[VMPRO] Compiled polymorphic VM vault with 48 encrypted payloads")
