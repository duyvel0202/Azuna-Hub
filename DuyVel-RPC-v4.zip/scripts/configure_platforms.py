import os
import re

proguard_rules = (
    "-optimizationpasses 5\n"
    "-allowaccessmodification\n"
    "-repackageclasses 'o'\n"
    "-overloadaggressively\n"
    "-renamesourcefileattribute SourceFile\n"
    "-keepattributes *Annotation*\n"
    "-keep class io.flutter.app.** { *; }\n"
    "-keep class io.flutter.plugin.** { *; }\n"
    "-keep class io.flutter.util.** { *; }\n"
    "-keep class io.flutter.view.** { *; }\n"
    "-keep class io.flutter.** { *; }\n"
    "-keep class io.flutter.plugins.** { *; }\n"
    "-assumenosideeffects class android.util.Log {\n"
    "    public static boolean isLoggable(java.lang.String, int);\n"
    "    public static int v(...);\n"
    "    public static int i(...);\n"
    "    public static int w(...);\n"
    "    public static int d(...);\n"
    "    public static int e(...);\n"
    "}\n"
)

manifest_path = os.path.join("android", "app", "src", "main", "AndroidManifest.xml")
if os.path.exists(manifest_path):
    with open(manifest_path, "r", encoding="utf-8") as f:
        content = f.read()
    content = re.sub(r'android:label="[^"]*"', 'android:label="DuyVel"', content)
    if 'android:allowBackup=' not in content:
        content = content.replace(
            "<application",
            '<application\n        android:allowBackup="false"\n        android:extractNativeLibs="false"',
            1,
        )
    if "android.permission.INTERNET" not in content:
        content = content.replace(
            "<application",
            '    <uses-permission android:name="android.permission.INTERNET"/>\n    <application',
            1,
        )
    if 'android:scheme="discord"' not in content:
        queries_block = (
            "    <queries>\n"
            "        <intent>\n"
            '            <action android:name="android.intent.action.VIEW"/>\n'
            '            <data android:scheme="https"/>\n'
            "        </intent>\n"
            "        <intent>\n"
            '            <action android:name="android.intent.action.VIEW"/>\n'
            '            <data android:scheme="discord"/>\n'
            "        </intent>\n"
            "    </queries>\n"
            "</manifest>"
        )
        content = content.replace("</manifest>", queries_block)
    with open(manifest_path, "w", encoding="utf-8") as f:
        f.write(content)

proguard_path = os.path.join("android", "app", "proguard-rules.pro")
if os.path.exists(os.path.join("android", "app")):
    with open(proguard_path, "w", encoding="utf-8") as f:
        f.write(proguard_rules)

for gradle_name in ["build.gradle.kts", "build.gradle"]:
    gradle_path = os.path.join("android", "app", gradle_name)
    if os.path.exists(gradle_path):
        with open(gradle_path, "r", encoding="utf-8") as f:
            g = f.read()
        if "proguard-rules.pro" not in g:
            if gradle_name.endswith(".kts"):
                g = g.replace(
                    'signingConfig = signingConfigs.getByName("debug")',
                    'signingConfig = signingConfigs.getByName("debug")\n'
                    '            isMinifyEnabled = true\n'
                    '            isShrinkResources = true\n'
                    '            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")',
                )
            else:
                g = g.replace(
                    "signingConfig = signingConfigs.debug",
                    "signingConfig = signingConfigs.debug\n"
                    "            minifyEnabled true\n"
                    "            shrinkResources true\n"
                    '            proguardFiles getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro"',
                )
            with open(gradle_path, "w", encoding="utf-8") as f:
                f.write(g)

plist_path = os.path.join("ios", "Runner", "Info.plist")
if os.path.exists(plist_path):
    with open(plist_path, "r", encoding="utf-8") as f:
        plist = f.read()
    plist = re.sub(
        r"(<key>CFBundleDisplayName</key>\s*<string>)[^<]*(</string>)",
        r"\g<1>DuyVel\g<2>",
        plist,
    )
    plist = re.sub(
        r"(<key>CFBundleName</key>\s*<string>)[^<]*(</string>)",
        r"\g<1>DuyVel\g<2>",
        plist,
    )
    if "LSApplicationQueriesSchemes" not in plist:
        scheme_block = (
            "\t<key>LSApplicationQueriesSchemes</key>\n"
            "\t<array>\n"
            "\t\t<string>discord</string>\n"
            "\t\t<string>https</string>\n"
            "\t</array>\n"
            "</dict>\n</plist>"
        )
        plist = re.sub(r"</dict>\s*</plist>", scheme_block, plist, count=1)
    with open(plist_path, "w", encoding="utf-8") as f:
        f.write(plist)

win_main_path = os.path.join("windows", "runner", "main.cpp")
if os.path.exists(win_main_path):
    with open(win_main_path, "r", encoding="utf-8") as f:
        win_cpp = f.read()
    win_cpp = win_cpp.replace('L"duyvel"', 'L"DuyVel"')
    with open(win_main_path, "w", encoding="utf-8") as f:
        f.write(win_cpp)

win_rc_path = os.path.join("windows", "runner", "Runner.rc")
if os.path.exists(win_rc_path):
    with open(win_rc_path, "r", encoding="utf-8") as f:
        win_rc = f.read()
    win_rc = win_rc.replace('"duyvel"', '"DuyVel"')
    with open(win_rc_path, "w", encoding="utf-8") as f:
        f.write(win_rc)

print("[CONFIG] Applied hardened Android R8/ProGuard, iOS, and Windows configs")
