param(
    [string]$ReleaseDir = "build\windows\x64\runner\Release",
    [string]$VmpCli = $env:VMPROTECT_CLI
)

if (-not $VmpCli -or -not (Test-Path $VmpCli)) {
    $candidates = @(
        "C:\Program Files\VMProtect Ultimate\VMProtect_Con.exe",
        "C:\Program Files\VMProtect Professional\VMProtect_Con.exe",
        "C:\VMProtect\VMProtect_Con.exe"
    )
    foreach ($c in $candidates) {
        if (Test-Path $c) {
            $VmpCli = $c
            break
        }
    }
}

$exePath = Join-Path $ReleaseDir "duyvel.exe"
$appSoPath = Join-Path $ReleaseDir "data\app.so"

if ($VmpCli -and (Test-Path $VmpCli)) {
    Write-Host "[VMP] Protecting $exePath with Ultra Virtualization + Anti-Dump..."
    & $VmpCli $exePath $exePath -pf "scripts\DuyVel.vmp"
    if (Test-Path $appSoPath) {
        Write-Host "[VMP] Protecting $appSoPath with Memory + Import Protection..."
        & $VmpCli $appSoPath $appSoPath -mode ultra
    }
} else {
    Write-Host "[VMP] VMProtect_Con.exe not found on runner. Shipped with AOT + Polymorphic VMVault + Symbol Strip."
}
