import 'dart:async';
import 'dart:io';
import '../models/rpc_models.dart';
import 'discord_gateway.dart';
import 'external_api.dart';

class MultiAccountManager {
  final Map<String, DiscordGatewayService> _gateways = {};
  final Map<String, DiscordUserProfile> userProfiles = {};
  final Map<String, bool> connectedStates = {};
  final Map<String, bool> readyStates = {};
  final Map<String, String> _lastDetectedTrackKey = {};
  Timer? _musicPollTimer;

  final void Function(LogEntry entry) onLog;
  final void Function() onUpdate;
  final List<AccountRpcProfile> Function() getAccounts;

  MultiAccountManager({
    required this.onLog,
    required this.onUpdate,
    required this.getAccounts,
  });

  void startAutoMusicSyncLoop() {
    _musicPollTimer?.cancel();
    _musicPollTimer = Timer.periodic(const Duration(seconds: 7), (_) async {
      final accounts = getAccounts();
      MusicTrackInfo? pcSpotifyTrack;
      bool checkedPc = false;

      for (final acc in accounts) {
        if (!(readyStates[acc.id] ?? false)) continue;
        if (!acc.music.enabled) continue;

        MusicTrackInfo? detected;
        if (acc.music.lastFmUsername.trim().isNotEmpty) {
          detected = await ExternalApiService.fetchLastFmNowPlaying(
              acc.music.lastFmUsername.trim());
        } else if (Platform.isWindows && acc.music.autoSyncPcSpotify) {
          if (!checkedPc) {
            pcSpotifyTrack = await ExternalApiService.detectWindowsSpotifyTrack();
            checkedPc = true;
          }
          detected = pcSpotifyTrack;
        }

        if (detected != null) {
          final trackKey = '${detected.artist}::${detected.title}';
          if (_lastDetectedTrackKey[acc.id] != trackKey) {
            _lastDetectedTrackKey[acc.id] = trackKey;
            acc.music.platformName = detected.platform;
            acc.music.songTitle = detected.title;
            acc.music.artistName = detected.artist;
            acc.music.albumName = detected.album;
            acc.music.durationSeconds = detected.durationSeconds;
            if (detected.thumbnailUrl.isNotEmpty) {
              acc.music.coverImageUrl = detected.thumbnailUrl;
            }
            if (detected.trackUrl.isNotEmpty) {
              acc.music.trackUrl = detected.trackUrl;
            }
            await updateAccountPresence(acc);
            onUpdate();
          }
        }
      }
    });
  }

  bool isConnected(String id) => connectedStates[id] ?? false;
  bool isReady(String id) => readyStates[id] ?? false;

  Future<void> connectAccount(AccountRpcProfile profile) async {
    var gw = _gateways[profile.id];
    if (gw == null) {
      gw = DiscordGatewayService(
        accountId: profile.id,
        accountTag: profile.label.isNotEmpty ? profile.label : 'Acc',
        onLog: onLog,
        onStateChanged: (id, conn, ready) {
          connectedStates[id] = conn;
          readyStates[id] = ready;
          onUpdate();
        },
        onUserReady: (id, user) {
          userProfiles[id] = user;
          onUpdate();
        },
      );
      _gateways[profile.id] = gw;
    }
    await gw.connect(profile);
  }

  Future<void> disconnectAccount(String id) async {
    final gw = _gateways[id];
    if (gw != null) {
      await gw.disconnect();
    }
    connectedStates[id] = false;
    readyStates[id] = false;
    onUpdate();
  }

  Future<void> removeAccount(String id) async {
    await disconnectAccount(id);
    _gateways.remove(id);
    userProfiles.remove(id);
    connectedStates.remove(id);
    readyStates.remove(id);
    _lastDetectedTrackKey.remove(id);
    onUpdate();
  }

  Future<void> updateAccountPresence(AccountRpcProfile profile) async {
    final gw = _gateways[profile.id];
    if (gw != null && gw.isReady) {
      await gw.updateDualPresence(profile);
    }
  }

  Future<void> connectAll(List<AccountRpcProfile> accounts) async {
    for (final acc in accounts) {
      if (acc.token.trim().isNotEmpty && !isConnected(acc.id)) {
        await connectAccount(acc);
        await Future.delayed(const Duration(milliseconds: 450));
      }
    }
  }

  Future<void> disconnectAll() async {
    for (final id in _gateways.keys.toList()) {
      await disconnectAccount(id);
    }
  }

  Future<void> dispose() async {
    _musicPollTimer?.cancel();
    await disconnectAll();
  }
}
