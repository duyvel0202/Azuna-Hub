import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import '../models/rpc_models.dart';
import '../security/vm_vault.dart';

class DiscordGatewayService {
  final String accountId;
  String accountTag;
  WebSocket? _socket;
  Timer? _heartbeatTimer;
  Timer? _reconnectTimer;
  int? _lastSequence;
  String _token = '';
  bool _manualDisconnect = false;
  bool _isConnected = false;
  bool _isReady = false;
  final Map<String, String> _assetCache = {};
  AccountRpcProfile? _activeProfile;

  final void Function(LogEntry entry) onLog;
  final void Function(String accountId, bool connected, bool ready)
      onStateChanged;
  final void Function(String accountId, DiscordUserProfile profile) onUserReady;

  DiscordGatewayService({
    required this.accountId,
    required this.accountTag,
    required this.onLog,
    required this.onStateChanged,
    required this.onUserReady,
  });

  bool get isConnected => _isConnected;
  bool get isReady => _isReady;

  void _log(String tag, String msg, {int level = 0}) {
    final now = DateTime.now();
    final hh = now.hour.toString().padLeft(2, '0');
    final mm = now.minute.toString().padLeft(2, '0');
    final ss = now.second.toString().padLeft(2, '0');
    onLog(LogEntry(
      timestamp: '$hh:$mm:$ss',
      accountTag: accountTag,
      tag: tag,
      message: msg,
      level: level,
    ));
  }

  Future<void> connect(AccountRpcProfile profile) async {
    _activeProfile = profile;
    _token = profile.token.trim().replaceAll('"', '');
    _manualDisconnect = false;

    if (_token.isEmpty) {
      _log('AUTH', 'Token trống, không thể kết nối', level: 2);
      return;
    }

    await _closeSocketOnly();
    _log('GATEWAY', 'Đang kết nối Discord Gateway v10...');

    try {
      _socket = await WebSocket.connect(
        VmVault.s(1),
        headers: {
          'User-Agent': VmVault.s(26),
        },
      );
      _isConnected = true;
      onStateChanged(accountId, _isConnected, _isReady);

      _socket!.listen(
        _handleMessage,
        onDone: _handleDone,
        onError: (err) {
          _log('GATEWAY', 'Lỗi socket: $err', level: 2);
        },
        cancelOnError: false,
      );
    } catch (e) {
      _isConnected = false;
      _isReady = false;
      onStateChanged(accountId, false, false);
      _log('GATEWAY', 'Không thể mở WebSocket: $e', level: 2);
      _scheduleReconnect();
    }
  }

  void _handleMessage(dynamic raw) {
    try {
      final decoded = jsonDecode(raw.toString()) as Map<String, dynamic>;
      final op = decoded['op'] as int?;
      final seq = decoded['s'] as int?;
      final eventName = decoded['t'] as String?;
      final data = decoded['d'];

      if (seq != null) {
        _lastSequence = seq;
      }

      if (op == 10 && data is Map<String, dynamic>) {
        final interval = (data['heartbeat_interval'] as num?)?.toInt() ?? 41250;
        _startHeartbeat(interval);
        _sendIdentify();
      } else if (op == 11) {
        _log('HEARTBEAT', 'ACK OK');
      } else if (op == 7 || op == 9) {
        _log('GATEWAY', 'Reconnect requested (OP $op)', level: 1);
        _scheduleReconnect();
      } else if (op == 0 &&
          eventName == 'READY' &&
          data is Map<String, dynamic>) {
        _isReady = true;
        onStateChanged(accountId, true, true);
        final user = data['user'] as Map<String, dynamic>?;
        if (user != null) {
          final uid = user['id']?.toString() ?? '';
          final uname = user['username']?.toString() ?? 'Unknown';
          final gname = user['global_name']?.toString() ?? uname;
          final av = user['avatar']?.toString() ?? '';
          final ext = av.startsWith('a_') ? 'gif' : 'png';
          final avUrl = av.isNotEmpty
              ? '${VmVault.s(7)}$uid/$av.$ext?size=256'
              : VmVault.s(8);
          accountTag = uname;
          onUserReady(
            accountId,
            DiscordUserProfile(
              id: uid,
              username: uname,
              globalName: gname,
              avatarUrl: avUrl,
            ),
          );
          _log('AUTH', 'Online: $gname (@$uname)', level: 3);
        }
        if (_activeProfile != null) {
          updateDualPresence(_activeProfile!);
        }
      }
    } catch (e) {
      _log('PARSER', 'Lỗi đọc gói tin: $e', level: 2);
    }
  }

  void _startHeartbeat(int intervalMs) {
    _heartbeatTimer?.cancel();
    _heartbeatTimer = Timer.periodic(Duration(milliseconds: intervalMs), (_) {
      _sendRaw({'op': 1, 'd': _lastSequence});
    });
  }

  void _sendIdentify() {
    _sendRaw({
      'op': 2,
      'd': {
        'token': _token,
        'properties': {
          'os': Platform.operatingSystem,
          'browser': VmVault.s(27),
          'device': VmVault.s(28),
        },
        'presence': {
          'status': _activeProfile?.status ?? 'online',
          'since': 0,
          'activities': [],
          'afk': false,
        },
      },
    });
  }

  Future<String?> _resolveExternalAsset(String rawUrl) async {
    final clean = rawUrl.trim();
    if (clean.isEmpty) return null;
    if (clean.startsWith('mp:') || !clean.startsWith('http')) {
      return clean;
    }
    if (_assetCache.containsKey(clean)) {
      return _assetCache[clean];
    }
    try {
      final appId = VmVault.s(0);
      final res = await http
          .post(
            Uri.parse('${VmVault.s(2)}$appId${VmVault.s(3)}'),
            headers: {
              VmVault.s(29): _token,
              VmVault.s(30): VmVault.s(31),
            },
            body: jsonEncode({
              'urls': [clean],
            }),
          )
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final list = jsonDecode(res.body) as List<dynamic>;
        if (list.isNotEmpty) {
          final path =
              (list.first as Map<String, dynamic>)['external_asset_path']
                  ?.toString();
          if (path != null && path.isNotEmpty) {
            final resolved = path.startsWith('mp:') ? path : 'mp:$path';
            _assetCache[clean] = resolved;
            return resolved;
          }
        }
      } else {
        _log('ASSET', 'HTTP ${res.statusCode} khi đồng bộ ảnh', level: 1);
      }
    } catch (e) {
      _log('ASSET', 'Lỗi tải ảnh: $e', level: 1);
    }
    return null;
  }

  Future<void> updateDualPresence(AccountRpcProfile profile) async {
    _activeProfile = profile;
    if (!_isReady || _socket == null) {
      return;
    }

    final appId = VmVault.s(0);
    final game = profile.game;
    final music = profile.music;
    final nowMs = DateTime.now().millisecondsSinceEpoch;
    final List<Map<String, dynamic>> activities = [];

    if (game.enabled) {
      final Map<String, dynamic> gameAssets = {};
      final lg = await _resolveExternalAsset(game.largeImageUrl);
      if (lg != null) {
        gameAssets['large_image'] = lg;
        if (game.largeImageText.trim().isNotEmpty) {
          gameAssets['large_text'] = game.largeImageText.trim();
        }
      }
      final sm = await _resolveExternalAsset(game.smallImageUrl);
      if (sm != null) {
        gameAssets['small_image'] = sm;
        if (game.smallImageText.trim().isNotEmpty) {
          gameAssets['small_text'] = game.smallImageText.trim();
        }
      }

      final Map<String, dynamic> gameActivity = {
        'name': game.resolvedName(),
        'type': 0,
        'application_id': appId,
        'timestamps': {'start': nowMs},
      };

      final details = game.resolvedDetails();
      if (details.isNotEmpty) {
        gameActivity['details'] = details;
      }
      final state = game.resolvedState();
      if (state.isNotEmpty) {
        gameActivity['state'] = state;
      }
      if (game.useParty && game.partyMax > 0 && game.partyCurrent > 0) {
        final cur = game.partyCurrent > game.partyMax
            ? game.partyMax
            : game.partyCurrent;
        gameActivity['party'] = {
          'id': 'duyvel_party_${accountId}_$nowMs',
          'size': [cur, game.partyMax],
        };
      }
      if (gameAssets.isNotEmpty) {
        gameActivity['assets'] = gameAssets;
      }
      if (game.showButton &&
          game.buttonLabel.trim().isNotEmpty &&
          game.buttonUrl.trim().startsWith('http')) {
        gameActivity['buttons'] = [game.buttonLabel.trim()];
        gameActivity['metadata'] = {
          'button_urls': [game.buttonUrl.trim()],
        };
      }
      activities.add(gameActivity);
    }

    if (music.enabled) {
      final Map<String, dynamic> musicAssets = {};
      final cover = await _resolveExternalAsset(music.coverImageUrl);
      if (cover != null) {
        musicAssets['large_image'] = cover;
        if (music.albumName.trim().isNotEmpty) {
          musicAssets['large_text'] = music.albumName.trim();
        }
      }

      final Map<String, dynamic> musicTimestamps = {'start': nowMs};
      if (music.showProgressBar && music.durationSeconds > 0) {
        musicTimestamps['end'] = nowMs + (music.durationSeconds * 1000);
      }

      final Map<String, dynamic> musicActivity = {
        'name': music.platformName.trim().isEmpty
            ? 'Spotify'
            : music.platformName.trim(),
        'type': 2,
        'application_id': appId,
        'timestamps': musicTimestamps,
      };

      if (music.songTitle.trim().isNotEmpty) {
        musicActivity['details'] = music.songTitle.trim();
      }
      if (music.artistName.trim().isNotEmpty) {
        musicActivity['state'] = music.artistName.trim();
      }
      if (musicAssets.isNotEmpty) {
        musicActivity['assets'] = musicAssets;
      }
      if (music.showButton &&
          music.buttonLabel.trim().isNotEmpty &&
          music.trackUrl.trim().startsWith('http')) {
        musicActivity['buttons'] = [music.buttonLabel.trim()];
        musicActivity['metadata'] = {
          'button_urls': [music.trackUrl.trim()],
        };
      }
      activities.add(musicActivity);
    }

    _sendRaw({
      'op': 3,
      'd': {
        'since': nowMs,
        'activities': activities,
        'status': profile.status,
        'afk': false,
      },
    });

    _log(
      'RPC',
      'Phát ${activities.length} thẻ (${game.enabled ? game.resolvedName() : "No Game"} | ${music.enabled ? music.songTitle : "No Music"})',
      level: 3,
    );
  }

  void _sendRaw(Map<String, dynamic> payload) {
    if (_socket == null) return;
    try {
      _socket!.add(jsonEncode(payload));
    } catch (e) {
      _log('GATEWAY', 'Lỗi gửi gói tin: $e', level: 2);
    }
  }

  void _handleDone() {
    final code = _socket?.closeCode;
    _isConnected = false;
    _isReady = false;
    _heartbeatTimer?.cancel();
    onStateChanged(accountId, false, false);

    if (code == 4004) {
      _log('AUTH', 'Token sai hoặc đã hết hạn (4004)', level: 2);
      _manualDisconnect = true;
      return;
    }

    if (!_manualDisconnect) {
      _log('GATEWAY', 'Mất kết nối ($code), tự nối lại sau 5s', level: 1);
      _scheduleReconnect();
    } else {
      _log('GATEWAY', 'Đã ngắt kết nối');
    }
  }

  void _scheduleReconnect() {
    if (_manualDisconnect) return;
    _reconnectTimer?.cancel();
    _reconnectTimer = Timer(const Duration(seconds: 5), () {
      if (!_manualDisconnect && _activeProfile != null) {
        connect(_activeProfile!);
      }
    });
  }

  Future<void> _closeSocketOnly() async {
    _heartbeatTimer?.cancel();
    _reconnectTimer?.cancel();
    try {
      await _socket?.close();
    } catch (_) {}
    _socket = null;
  }

  Future<void> disconnect() async {
    _manualDisconnect = true;
    await _closeSocketOnly();
    _isConnected = false;
    _isReady = false;
    onStateChanged(accountId, false, false);
  }
}
