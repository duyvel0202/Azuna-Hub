import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import '../security/vm_vault.dart';

class ServerInviteInfo {
  final String name;
  final String iconUrl;
  final int memberCount;
  final int onlineCount;

  ServerInviteInfo({
    required this.name,
    required this.iconUrl,
    required this.memberCount,
    required this.onlineCount,
  });
}

class RobloxGameInfo {
  final String name;
  final String creator;
  final String iconUrl;
  final int playing;

  RobloxGameInfo({
    required this.name,
    required this.creator,
    required this.iconUrl,
    required this.playing,
  });
}

class MusicTrackInfo {
  final String title;
  final String artist;
  final String album;
  final String thumbnailUrl;
  final int durationSeconds;
  final String platform;
  final String trackUrl;

  MusicTrackInfo({
    required this.title,
    required this.artist,
    required this.album,
    required this.thumbnailUrl,
    required this.durationSeconds,
    required this.platform,
    required this.trackUrl,
  });
}

class ValorantCatalog {
  final Map<String, String> agents;
  final Map<String, String> maps;
  final Map<String, String> ranks;

  ValorantCatalog({
    required this.agents,
    required this.maps,
    required this.ranks,
  });
}

class ExternalApiService {
  static ValorantCatalog? _cachedValorant;

  static Future<ServerInviteInfo?> fetchDiscordInvite(String code) async {
    try {
      final res = await http
          .get(Uri.parse('${VmVault.s(4)}$code${VmVault.s(5)}'))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode != 200) return null;
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      final guild = data['guild'] as Map<String, dynamic>?;
      if (guild == null) return null;
      final id = guild['id']?.toString() ?? '';
      final icon = guild['icon']?.toString() ?? '';
      final ext = icon.startsWith('a_') ? 'gif' : 'png';
      final iconUrl = icon.isNotEmpty
          ? '${VmVault.s(6)}$id/$icon.$ext?size=512'
          : '';
      return ServerInviteInfo(
        name: guild['name']?.toString() ?? VmVault.s(9),
        iconUrl: iconUrl,
        memberCount: (data['approximate_member_count'] as num?)?.toInt() ?? 0,
        onlineCount: (data['approximate_presence_count'] as num?)?.toInt() ?? 0,
      );
    } catch (_) {
      return null;
    }
  }

  static Future<ValorantCatalog> fetchValorantCatalog() async {
    if (_cachedValorant != null) return _cachedValorant!;
    final agents = <String, String>{
      'Jett':
          'https://media.valorant-api.com/agents/add6443a-41bd-e414-f6ad-e58d267f4e95/displayicon.png',
      'Reyna':
          'https://media.valorant-api.com/agents/a3bfb853-43b2-7238-a4f1-ad90e9e46bcc/displayicon.png',
      'Clove':
          'https://media.valorant-api.com/agents/1dbf2edd-4729-0984-3115-daa5eed44993/displayicon.png',
      'Omen':
          'https://media.valorant-api.com/agents/8e253930-4c05-31dd-1b6c-968525494517/displayicon.png',
      'Iso':
          'https://media.valorant-api.com/agents/0e38b510-41a8-5780-5e8f-568b2a4f2d6c/displayicon.png',
    };
    final maps = <String, String>{
      'Ascent':
          'https://media.valorant-api.com/maps/7eaecc1b-4337-bbf6-6ab9-04b8f06b3319/splash.png',
      'Bind':
          'https://media.valorant-api.com/maps/2c9d57ec-4431-9c5e-2939-8f9ef6dd5cba/splash.png',
      'Haven':
          'https://media.valorant-api.com/maps/2bee0dc9-4ffe-519b-1cbd-7fbe763a6047/splash.png',
      'Split':
          'https://media.valorant-api.com/maps/d960549e-485c-e861-8d71-aa9d1aed12a2/splash.png',
      'Lotus':
          'https://media.valorant-api.com/maps/2fe4ed3a-450a-948b-6d6b-e89a78e680a9/splash.png',
    };
    final ranks = <String, String>{
      'Unranked': '',
      'Iron 3':
          'https://media.valorant-api.com/competitivetiers/03621f52-342b-cf4e-4f86-9350a49c6d04/5/largeicon.png',
      'Bronze 3':
          'https://media.valorant-api.com/competitivetiers/03621f52-342b-cf4e-4f86-9350a49c6d04/8/largeicon.png',
      'Silver 3':
          'https://media.valorant-api.com/competitivetiers/03621f52-342b-cf4e-4f86-9350a49c6d04/11/largeicon.png',
      'Gold 3':
          'https://media.valorant-api.com/competitivetiers/03621f52-342b-cf4e-4f86-9350a49c6d04/14/largeicon.png',
      'Platinum 3':
          'https://media.valorant-api.com/competitivetiers/03621f52-342b-cf4e-4f86-9350a49c6d04/17/largeicon.png',
      'Diamond 3':
          'https://media.valorant-api.com/competitivetiers/03621f52-342b-cf4e-4f86-9350a49c6d04/20/largeicon.png',
      'Ascendant 3':
          'https://media.valorant-api.com/competitivetiers/03621f52-342b-cf4e-4f86-9350a49c6d04/23/largeicon.png',
      'Immortal 2':
          'https://media.valorant-api.com/competitivetiers/03621f52-342b-cf4e-4f86-9350a49c6d04/25/largeicon.png',
      'Radiant':
          'https://media.valorant-api.com/competitivetiers/03621f52-342b-cf4e-4f86-9350a49c6d04/27/largeicon.png',
    };

    try {
      final aRes = await http
          .get(Uri.parse(VmVault.s(12)))
          .timeout(const Duration(seconds: 8));
      if (aRes.statusCode == 200) {
        final data =
            (jsonDecode(aRes.body) as Map<String, dynamic>)['data'] as List?;
        if (data != null) {
          for (final item in data) {
            final m = item as Map<String, dynamic>;
            final name = m['displayName']?.toString() ?? '';
            final icon = m['displayIcon']?.toString() ?? '';
            if (name.isNotEmpty && icon.isNotEmpty) {
              agents[name] = icon;
            }
          }
        }
      }
    } catch (_) {}

    try {
      final mRes = await http
          .get(Uri.parse(VmVault.s(13)))
          .timeout(const Duration(seconds: 8));
      if (mRes.statusCode == 200) {
        final data =
            (jsonDecode(mRes.body) as Map<String, dynamic>)['data'] as List?;
        if (data != null) {
          for (final item in data) {
            final m = item as Map<String, dynamic>;
            final name = m['displayName']?.toString() ?? '';
            final splash = m['splash']?.toString() ?? '';
            if (name.isNotEmpty && splash.isNotEmpty && name != 'The Range') {
              maps[name] = splash;
            }
          }
        }
      }
    } catch (_) {}

    try {
      final tRes = await http
          .get(Uri.parse(VmVault.s(14)))
          .timeout(const Duration(seconds: 8));
      if (tRes.statusCode == 200) {
        final list =
            (jsonDecode(tRes.body) as Map<String, dynamic>)['data'] as List?;
        if (list != null && list.isNotEmpty) {
          final latest = list.last as Map<String, dynamic>;
          final tiers = latest['tiers'] as List? ?? [];
          final loadedRanks = <String, String>{'Unranked': ''};
          for (final t in tiers) {
            final tm = t as Map<String, dynamic>;
            final rawName = tm['tierName']?.toString() ?? '';
            final icon = tm['largeIcon']?.toString() ?? '';
            if (rawName.isNotEmpty &&
                icon.isNotEmpty &&
                !rawName.contains('UNUSED')) {
              final formatted = rawName
                  .split(' ')
                  .map((w) => w.isEmpty
                      ? ''
                      : '${w[0].toUpperCase()}${w.substring(1).toLowerCase()}')
                  .join(' ');
              loadedRanks[formatted] = icon;
            }
          }
          if (loadedRanks.length > 5) {
            ranks
              ..clear()
              ..addAll(loadedRanks);
          }
        }
      }
    } catch (_) {}

    _cachedValorant = ValorantCatalog(
      agents: agents,
      maps: maps,
      ranks: ranks,
    );
    return _cachedValorant!;
  }

  static Future<RobloxGameInfo?> fetchRobloxGameByPlaceId(
      String placeId) async {
    final cleanId = placeId.replaceAll(RegExp(r'[^0-9]'), '');
    if (cleanId.isEmpty) return null;
    try {
      final uniRes = await http
          .get(Uri.parse('${VmVault.s(15)}$cleanId${VmVault.s(16)}'))
          .timeout(const Duration(seconds: 10));
      if (uniRes.statusCode != 200) return null;
      final uniData = jsonDecode(uniRes.body) as Map<String, dynamic>;
      final universeId = uniData['universeId']?.toString();
      if (universeId == null || universeId.isEmpty) return null;

      final gameRes = await http
          .get(Uri.parse('${VmVault.s(17)}$universeId'))
          .timeout(const Duration(seconds: 10));
      if (gameRes.statusCode != 200) return null;
      final gameJson = jsonDecode(gameRes.body) as Map<String, dynamic>;
      final list = gameJson['data'] as List<dynamic>? ?? [];
      if (list.isEmpty) return null;
      final item = list.first as Map<String, dynamic>;

      String iconUrl = '';
      try {
        final thumbRes = await http
            .get(Uri.parse('${VmVault.s(18)}$universeId${VmVault.s(19)}'))
            .timeout(const Duration(seconds: 10));
        if (thumbRes.statusCode == 200) {
          final thumbJson = jsonDecode(thumbRes.body) as Map<String, dynamic>;
          final thumbData = thumbJson['data'] as List<dynamic>? ?? [];
          if (thumbData.isNotEmpty) {
            iconUrl = (thumbData.first as Map<String, dynamic>)['imageUrl']
                    ?.toString() ??
                '';
          }
        }
      } catch (_) {}

      final creatorMap = item['creator'] as Map<String, dynamic>?;
      return RobloxGameInfo(
        name: item['name']?.toString() ?? 'Roblox Experience',
        creator: creatorMap?['name']?.toString() ?? 'Roblox',
        iconUrl: iconUrl,
        playing: (item['playing'] as num?)?.toInt() ?? 0,
      );
    } catch (_) {
      return null;
    }
  }

  static Future<MusicTrackInfo?> fetchMusicOEmbed(String url) async {
    final trimmed = url.trim();
    if (trimmed.isEmpty) return null;
    try {
      String endpoint = '';
      String platform = 'Spotify';
      if (trimmed.contains('soundcloud.com')) {
        platform = 'SoundCloud';
        endpoint = '${VmVault.s(20)}${Uri.encodeComponent(trimmed)}';
      } else if (trimmed.contains('spotify.com')) {
        platform = 'Spotify';
        endpoint = '${VmVault.s(21)}${Uri.encodeComponent(trimmed)}';
      } else if (trimmed.contains('youtube.com') ||
          trimmed.contains('youtu.be')) {
        platform = 'YouTube Music';
        endpoint = '${VmVault.s(22)}${Uri.encodeComponent(trimmed)}';
      } else {
        return null;
      }

      final res =
          await http.get(Uri.parse(endpoint)).timeout(const Duration(seconds: 10));
      if (res.statusCode != 200) return null;
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      final title = data['title']?.toString() ?? 'Unknown Track';
      final author = data['author_name']?.toString() ?? '';
      final thumb = data['thumbnail_url']?.toString() ?? '';

      final enriched = await searchMusicTrack(
          author.isNotEmpty ? '$title $author' : title);
      return MusicTrackInfo(
        title: title,
        artist: author.isNotEmpty ? author : (enriched?.artist ?? platform),
        album: enriched?.album ?? platform,
        thumbnailUrl:
            thumb.isNotEmpty ? thumb : (enriched?.thumbnailUrl ?? ''),
        durationSeconds: enriched?.durationSeconds ?? 210,
        platform: platform,
        trackUrl: trimmed,
      );
    } catch (_) {
      return null;
    }
  }

  static Future<MusicTrackInfo?> searchMusicTrack(String query) async {
    final q = query.trim();
    if (q.isEmpty) return null;
    try {
      final res = await http
          .get(Uri.parse(
              '${VmVault.s(23)}${Uri.encodeComponent(q)}${VmVault.s(24)}'))
          .timeout(const Duration(seconds: 8));
      if (res.statusCode != 200) return null;
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      final results = data['results'] as List<dynamic>? ?? [];
      if (results.isEmpty) return null;
      final item = results.first as Map<String, dynamic>;
      final art = (item['artworkUrl100']?.toString() ?? '')
          .replaceAll('100x100bb', '600x600bb');
      final durMs = (item['trackTimeMillis'] as num?)?.toInt() ?? 210000;
      return MusicTrackInfo(
        title: item['trackName']?.toString() ?? q,
        artist: item['artistName']?.toString() ?? 'Unknown Artist',
        album: item['collectionName']?.toString() ?? 'Spotify',
        thumbnailUrl: art,
        durationSeconds: (durMs / 1000).round(),
        platform: 'Spotify',
        trackUrl: item['trackViewUrl']?.toString() ?? VmVault.s(10),
      );
    } catch (_) {
      return null;
    }
  }

  static Future<MusicTrackInfo?> detectWindowsSpotifyTrack() async {
    if (!Platform.isWindows) return null;
    try {
      final res = await Process.run(
        'powershell',
        [
          '-NoProfile',
          '-Command',
          "(Get-Process Spotify -ErrorAction SilentlyContinue | Where-Object { \$_.MainWindowTitle -ne '' } | Select-Object -First 1 -ExpandProperty MainWindowTitle)"
        ],
      ).timeout(const Duration(seconds: 4));
      final raw = res.stdout.toString().trim();
      if (raw.isEmpty ||
          raw == 'Spotify' ||
          raw == 'Spotify Free' ||
          raw == 'Spotify Premium' ||
          !raw.contains(' - ')) {
        return null;
      }
      final idx = raw.indexOf(' - ');
      final artist = raw.substring(0, idx).trim();
      final title = raw.substring(idx + 3).trim();
      if (title.isEmpty) return null;
      final meta = await searchMusicTrack('$artist $title');
      return MusicTrackInfo(
        title: title,
        artist: artist,
        album: meta?.album ?? 'Spotify',
        thumbnailUrl: meta?.thumbnailUrl ?? '',
        durationSeconds: meta?.durationSeconds ?? 210,
        platform: 'Spotify',
        trackUrl: meta?.trackUrl ?? 'https://open.spotify.com',
      );
    } catch (_) {
      return null;
    }
  }

  static Future<MusicTrackInfo?> fetchLastFmNowPlaying(String username) async {
    final user = username.trim();
    if (user.isEmpty) return null;
    try {
      final res = await http
          .get(
            Uri.parse('${VmVault.s(25)}${Uri.encodeComponent(user)}'),
            headers: {
              'User-Agent': VmVault.s(26),
            },
          )
          .timeout(const Duration(seconds: 10));
      if (res.statusCode != 200) return null;
      final body = res.body;
      final rowMatch = RegExp(
              r'data-scrobbling-now="true"[\s\S]*?class="chartlist-name"[\s\S]*?title="([^"]+)"[\s\S]*?class="chartlist-artist"[\s\S]*?title="([^"]+)"')
          .firstMatch(body);
      if (rowMatch == null) return null;
      final title = _decodeHtml(rowMatch.group(1) ?? '');
      final artist = _decodeHtml(rowMatch.group(2) ?? '');
      if (title.isEmpty) return null;
      final meta = await searchMusicTrack('$artist $title');
      return MusicTrackInfo(
        title: title,
        artist: artist,
        album: meta?.album ?? 'Spotify',
        thumbnailUrl: meta?.thumbnailUrl ?? '',
        durationSeconds: meta?.durationSeconds ?? 210,
        platform: 'Spotify',
        trackUrl: meta?.trackUrl ?? 'https://open.spotify.com',
      );
    } catch (_) {
      return null;
    }
  }

  static String _decodeHtml(String input) {
    return input
        .replaceAll('&amp;', '&')
        .replaceAll('&quot;', '"')
        .replaceAll('&#39;', "'")
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>');
  }
}
