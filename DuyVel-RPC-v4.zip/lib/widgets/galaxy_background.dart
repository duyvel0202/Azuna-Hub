import 'dart:math';
import 'package:flutter/material.dart';

class _Star {
  double x;
  double y;
  double radius;
  double speed;
  double alpha;

  _Star(this.x, this.y, this.radius, this.speed, this.alpha);
}

class GalaxyBackground extends StatefulWidget {
  final Widget child;
  const GalaxyBackground({super.key, required this.child});

  @override
  State<GalaxyBackground> createState() => _GalaxyBackgroundState();
}

class _GalaxyBackgroundState extends State<GalaxyBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final List<_Star> _stars;

  @override
  void initState() {
    super.initState();
    final rng = Random(42026);
    _stars = List.generate(90, (_) {
      return _Star(
        rng.nextDouble(),
        rng.nextDouble(),
        0.6 + rng.nextDouble() * 1.4,
        0.00018 + rng.nextDouble() * 0.00045,
        0.25 + rng.nextDouble() * 0.65,
      );
    });
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 60),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned.fill(
          child: AnimatedBuilder(
            animation: _controller,
            builder: (context, _) {
              return CustomPaint(
                painter: _GalaxyPainter(_stars, _controller.value),
              );
            },
          ),
        ),
        widget.child,
      ],
    );
  }
}

class _GalaxyPainter extends CustomPainter {
  final List<_Star> stars;
  final double tick;

  _GalaxyPainter(this.stars, this.tick);

  @override
  void paint(Canvas canvas, Size size) {
    final bgPaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Color(0xFF05070E),
          Color(0xFF0A0F1F),
          Color(0xFF070912),
        ],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), bgPaint);

    final nebula1 = Paint()
      ..shader = RadialGradient(
        colors: [
          const Color(0xFF3B2878).withAlpha(42),
          Colors.transparent,
        ],
      ).createShader(Rect.fromCircle(
        center: Offset(size.width * 0.2, size.height * 0.18),
        radius: size.width * 0.55,
      ));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), nebula1);

    final nebula2 = Paint()
      ..shader = RadialGradient(
        colors: [
          const Color(0xFF1D4E89).withAlpha(35),
          Colors.transparent,
        ],
      ).createShader(Rect.fromCircle(
        center: Offset(size.width * 0.85, size.height * 0.75),
        radius: size.width * 0.5,
      ));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), nebula2);

    final starPaint = Paint()..style = PaintingStyle.fill;
    for (final s in stars) {
      final dy = (s.y - tick * s.speed * 180) % 1.0;
      final py = dy < 0 ? dy + 1.0 : dy;
      final px = (s.x + sin(tick * 2 * pi + s.y * 6) * 0.008) % 1.0;
      starPaint.color =
          const Color(0xFFDCE6FF).withAlpha((s.alpha * 255).toInt());
      canvas.drawCircle(
        Offset(px * size.width, py * size.height),
        s.radius,
        starPaint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _GalaxyPainter oldDelegate) => true;
}
