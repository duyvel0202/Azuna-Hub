enum GamePresetType {
  valorant,
  lienQuan,
  roblox,
  other,
}

class LogEntry {
  final String timestamp;
  final String accountTag;
  final String tag;
  final String message;
  final int level;

  LogEntry({
    required this.timestamp,
    required this.accountTag,
    required this.tag,
    required this.message,
    required this.level,
  });
}

class DiscordUserProfile {
  final String id;
  final String username;
  final String globalName;
  final String avatarUrl;

  DiscordUserProfile({
    required this.id,
    required this.username,
    required this.globalName,
    required this.avatarUrl,
  });
}

class GameRpcConfig {
  bool enabled;
  GamePresetType preset;
  String gameName;
  String mode;
  String rank;
  String rr;
  String heroOrAgent;
  String mapOrServer;
  String score;
  String kda;
  String customDetails;
  String customState;
  int partyCurrent;
  int partyMax;
  bool useParty;
  String largeImageUrl;
  String largeImageText;
  String smallImageUrl;
  String smallImageText;
  String buttonLabel;
  String buttonUrl;
  bool showButton;
  String robloxPlaceId;
  bool robloxUseGameTitleAsActivityName;

  GameRpcConfig({
    this.enabled = true,
    this.preset = GamePresetType.valorant,
    this.gameName = 'VALORANT',
    this.mode = '5v5 Đấu Hạng (Competitive)',
    this.rank = 'Immortal 2',
    this.rr = '78',
    this.heroOrAgent = 'Jett',
    this.mapOrServer = 'Ascent',
    this.score = '10 - 7',
    this.kda = '18/9/4',
    this.customDetails = '5v5 Đấu Hạng (Competitive) • Immortal 2 (78 RR)',
    this.customState = 'Ascent • Jett • 10 - 7 • KDA 18/9/4',
    this.partyCurrent = 5,
    this.partyMax = 5,
    this.useParty = true,
    this.largeImageUrl =
        'https://media.valorant-api.com/maps/7eaecc1b-4337-bbf6-6ab9-04b8f06b3319/splash.png',
    this.largeImageText = 'Ascent - VALORANT',
    this.smallImageUrl =
        'https://media.valorant-api.com/agents/add6443a-41bd-e414-f6ad-e58d267f4e95/displayicon.png',
    this.smallImageText = 'Jett | Immortal 2 (78 RR)',
    this.buttonLabel = 'Join Discord hxmoon',
    this.buttonUrl = 'https://discord.gg/hxmoon',
    this.showButton = true,
    this.robloxPlaceId = '2753915549',
    this.robloxUseGameTitleAsActivityName = false,
  });

  String resolvedName() {
    if (preset == GamePresetType.valorant) {
      return 'VALORANT';
    }
    if (preset == GamePresetType.lienQuan) {
      return 'Liên Quân Mobile';
    }
    if (preset == GamePresetType.roblox) {
      if (robloxUseGameTitleAsActivityName && gameName.trim().isNotEmpty) {
        return gameName.trim();
      }
      return 'Roblox';
    }
    return gameName.trim().isEmpty ? 'DuyVel Game' : gameName.trim();
  }

  String resolvedDetails() {
    if (preset == GamePresetType.valorant) {
      final r = rank.trim();
      final rrVal = rr.trim();
      if (r.isNotEmpty && r != 'Unranked') {
        final rrSuffix = rrVal.isNotEmpty ? ' ($rrVal RR)' : '';
        return '$mode • $r$rrSuffix';
      }
      return mode;
    }
    if (preset == GamePresetType.lienQuan) {
      final r = rank.trim();
      if (r.isNotEmpty && r != 'Không hiển thị') {
        return '$mode • Rank $r';
      }
      return mode;
    }
    if (preset == GamePresetType.roblox) {
      if (robloxUseGameTitleAsActivityName) {
        return mode.trim().isEmpty ? 'Public Server' : mode.trim();
      }
      final g = gameName.trim().isEmpty ? 'Blox Fruits' : gameName.trim();
      return 'Đang chơi: $g';
    }
    return customDetails.trim();
  }

  String resolvedState() {
    if (preset == GamePresetType.valorant) {
      final parts = <String>[];
      if (mapOrServer.trim().isNotEmpty) {
        parts.add(mapOrServer.trim());
      }
      if (heroOrAgent.trim().isNotEmpty) {
        parts.add(heroOrAgent.trim());
      }
      if (score.trim().isNotEmpty) {
        parts.add(score.trim());
      }
      if (kda.trim().isNotEmpty) {
        parts.add('KDA ${kda.trim()}');
      }
      return parts.isEmpty ? 'In Match' : parts.join(' • ');
    }
    if (preset == GamePresetType.lienQuan) {
      final parts = <String>[];
      if (heroOrAgent.trim().isNotEmpty) {
        parts.add('Tướng: ${heroOrAgent.trim()}');
      }
      if (kda.trim().isNotEmpty) {
        parts.add('KDA ${kda.trim()}');
      }
      if (customState.trim().isNotEmpty) {
        parts.add(customState.trim());
      }
      return parts.isEmpty ? 'Đang trong trận' : parts.join(' • ');
    }
    if (preset == GamePresetType.roblox) {
      final parts = <String>[];
      if (!robloxUseGameTitleAsActivityName && mode.trim().isNotEmpty) {
        parts.add(mode.trim());
      }
      if (mapOrServer.trim().isNotEmpty) {
        parts.add(mapOrServer.trim());
      }
      if (customState.trim().isNotEmpty) {
        parts.add(customState.trim());
      }
      return parts.isEmpty ? 'Public Server' : parts.join(' • ');
    }
    return customState.trim();
  }

  Map<String, dynamic> toJson() => {
        'enabled': enabled,
        'preset': preset.index,
        'gameName': gameName,
        'mode': mode,
        'rank': rank,
        'rr': rr,
        'heroOrAgent': heroOrAgent,
        'mapOrServer': mapOrServer,
        'score': score,
        'kda': kda,
        'customDetails': customDetails,
        'customState': customState,
        'partyCurrent': partyCurrent,
        'partyMax': partyMax,
        'useParty': useParty,
        'largeImageUrl': largeImageUrl,
        'largeImageText': largeImageText,
        'smallImageUrl': smallImageUrl,
        'smallImageText': smallImageText,
        'buttonLabel': buttonLabel,
        'buttonUrl': buttonUrl,
        'showButton': showButton,
        'robloxPlaceId': robloxPlaceId,
        'robloxUseGameTitleAsActivityName': robloxUseGameTitleAsActivityName,
      };

  factory GameRpcConfig.fromJson(Map<String, dynamic> j) {
    final idx = (j['preset'] is int) ? j['preset'] as int : 0;
    final safeIdx = (idx >= 0 && idx < GamePresetType.values.length) ? idx : 0;
    return GameRpcConfig(
      enabled: j['enabled'] ?? true,
      preset: GamePresetType.values[safeIdx],
      gameName: j['gameName'] ?? 'VALORANT',
      mode: j['mode'] ?? '5v5 Đấu Hạng (Competitive)',
      rank: j['rank'] ?? 'Immortal 2',
      rr: j['rr'] ?? '78',
      heroOrAgent: j['heroOrAgent'] ?? 'Jett',
      mapOrServer: j['mapOrServer'] ?? 'Ascent',
      score: j['score'] ?? '10 - 7',
      kda: j['kda'] ?? '18/9/4',
      customDetails: j['customDetails'] ?? '',
      customState: j['customState'] ?? '',
      partyCurrent: j['partyCurrent'] ?? 5,
      partyMax: j['partyMax'] ?? 5,
      useParty: j['useParty'] ?? true,
      largeImageUrl: j['largeImageUrl'] ??
          'https://media.valorant-api.com/maps/7eaecc1b-4337-bbf6-6ab9-04b8f06b3319/splash.png',
      largeImageText: j['largeImageText'] ?? 'Ascent - VALORANT',
      smallImageUrl: j['smallImageUrl'] ??
          'https://media.valorant-api.com/agents/add6443a-41bd-e414-f6ad-e58d267f4e95/displayicon.png',
      smallImageText: j['smallImageText'] ?? 'Jett | Immortal 2',
      buttonLabel: j['buttonLabel'] ?? 'Join Discord hxmoon',
      buttonUrl: j['buttonUrl'] ?? 'https://discord.gg/hxmoon',
      showButton: j['showButton'] ?? true,
      robloxPlaceId: j['robloxPlaceId'] ?? '2753915549',
      robloxUseGameTitleAsActivityName:
          j['robloxUseGameTitleAsActivityName'] ?? false,
    );
  }
}

class MusicRpcConfig {
  bool enabled;
  bool autoSyncPcSpotify;
  String lastFmUsername;
  String platformName;
  String songTitle;
  String artistName;
  String albumName;
  int durationSeconds;
  bool showProgressBar;
  String coverImageUrl;
  String trackUrl;
  String buttonLabel;
  bool showButton;

  MusicRpcConfig({
    this.enabled = true,
    this.autoSyncPcSpotify = true,
    this.lastFmUsername = '',
    this.platformName = 'Spotify',
    this.songTitle = 'Hong Khong Gai (Remix)',
    this.artistName = 'DuyVel Playlist',
    this.albumName = 'Spotify',
    this.durationSeconds = 215,
    this.showProgressBar = true,
    this.coverImageUrl = '',
    this.trackUrl = 'https://discord.gg/hxmoon',
    this.buttonLabel = 'Nghe trên Spotify',
    this.showButton = true,
  });

  Map<String, dynamic> toJson() => {
        'enabled': enabled,
        'autoSyncPcSpotify': autoSyncPcSpotify,
        'lastFmUsername': lastFmUsername,
        'platformName': platformName,
        'songTitle': songTitle,
        'artistName': artistName,
        'albumName': albumName,
        'durationSeconds': durationSeconds,
        'showProgressBar': showProgressBar,
        'coverImageUrl': coverImageUrl,
        'trackUrl': trackUrl,
        'buttonLabel': buttonLabel,
        'showButton': showButton,
      };

  factory MusicRpcConfig.fromJson(Map<String, dynamic> j) {
    return MusicRpcConfig(
      enabled: j['enabled'] ?? true,
      autoSyncPcSpotify: j['autoSyncPcSpotify'] ?? true,
      lastFmUsername: j['lastFmUsername'] ?? '',
      platformName: j['platformName'] ?? 'Spotify',
      songTitle: j['songTitle'] ?? 'Hong Khong Gai (Remix)',
      artistName: j['artistName'] ?? 'DuyVel Playlist',
      albumName: j['albumName'] ?? 'Spotify',
      durationSeconds: j['durationSeconds'] ?? 215,
      showProgressBar: j['showProgressBar'] ?? true,
      coverImageUrl: j['coverImageUrl'] ?? '',
      trackUrl: j['trackUrl'] ?? 'https://discord.gg/hxmoon',
      buttonLabel: j['buttonLabel'] ?? 'Nghe trên Spotify',
      showButton: j['showButton'] ?? true,
    );
  }
}

class AccountRpcProfile {
  final String id;
  String token;
  String label;
  String status;
  GameRpcConfig game;
  MusicRpcConfig music;

  AccountRpcProfile({
    required this.id,
    required this.token,
    this.label = '',
    this.status = 'online',
    GameRpcConfig? game,
    MusicRpcConfig? music,
  })  : game = game ?? GameRpcConfig(),
        music = music ?? MusicRpcConfig();

  Map<String, dynamic> toJson() => {
        'id': id,
        'token': token,
        'label': label,
        'status': status,
        'game': game.toJson(),
        'music': music.toJson(),
      };

  factory AccountRpcProfile.fromJson(Map<String, dynamic> j) {
    return AccountRpcProfile(
      id: j['id']?.toString() ??
          DateTime.now().microsecondsSinceEpoch.toString(),
      token: j['token']?.toString() ?? '',
      label: j['label']?.toString() ?? '',
      status: j['status']?.toString() ?? 'online',
      game: j['game'] is Map<String, dynamic>
          ? GameRpcConfig.fromJson(j['game'] as Map<String, dynamic>)
          : GameRpcConfig(),
      music: j['music'] is Map<String, dynamic>
          ? MusicRpcConfig.fromJson(j['music'] as Map<String, dynamic>)
          : MusicRpcConfig(),
    );
  }
}
