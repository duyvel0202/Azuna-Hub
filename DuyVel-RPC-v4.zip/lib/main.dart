import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'models/rpc_models.dart';
import 'security/runtime_guard.dart';
import 'security/vm_vault.dart';
import 'services/external_api.dart';
import 'services/multi_account_manager.dart';
import 'widgets/galaxy_background.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  RuntimeGuard.engage();
  runApp(const DuyVelApp());
}

class DuyVelApp extends StatelessWidget {
  const DuyVelApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: VmVault.s(28),
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF060810),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF5865F2),
          secondary: Color(0xFF23A55A),
          surface: Color(0xFF111524),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF0D111E),
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: Color(0xFF222942)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: Color(0xFF222942)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: Color(0xFF5865F2)),
          ),
        ),
        useMaterial3: true,
      ),
      home: const DuyVelHomePage(),
    );
  }
}

class DuyVelHomePage extends StatefulWidget {
  const DuyVelHomePage({super.key});

  @override
  State<DuyVelHomePage> createState() => _DuyVelHomePageState();
}

class _DuyVelHomePageState extends State<DuyVelHomePage> {
  int _navIndex = 0;
  int _selectedAccIndex = 0;
  bool _fetchingRoblox = false;
  bool _fetchingMusic = false;

  ValorantCatalog? _valCatalog;
  final List<LogEntry> _logs = [];
  List<AccountRpcProfile> _accounts = [];
  late final MultiAccountManager _manager;

  final _gameNameCtrl = TextEditingController();
  final _rrCtrl = TextEditingController();
  final _scoreCtrl = TextEditingController();
  final _kdaCtrl = TextEditingController();
  final _heroCtrl = TextEditingController();
  final _mapCtrl = TextEditingController();
  final _customDetailsCtrl = TextEditingController();
  final _customStateCtrl = TextEditingController();
  final _gameBtnLabelCtrl = TextEditingController();
  final _gameBtnUrlCtrl = TextEditingController();
  final _robloxPlaceCtrl = TextEditingController();

  final _musicQueryCtrl = TextEditingController();
  final _lastFmCtrl = TextEditingController();
  final _musicTitleCtrl = TextEditingController();
  final _musicArtistCtrl = TextEditingController();
  final _musicAlbumCtrl = TextEditingController();
  final _musicDurationCtrl = TextEditingController();
  final _musicBtnLabelCtrl = TextEditingController();
  final _musicTrackUrlCtrl = TextEditingController();

  static const List<String> _valorantModes = [
    '5v5 Đấu Hạng (Competitive)',
    '5v5 Đấu Thường (Unrated)',
    '5v5 Swiftplay',
    '5v5 Spike Rush',
    'Đấu Đội (Team Deathmatch)',
    'Deathmatch',
    'Custom Game',
  ];

  static const List<String> _lienQuanModes = [
    '5v5 Đấu Hạng',
    '5v5 Đấu Thường',
    '5v5 Đấu Đỉnh Cao',
    '5v5 Đấu Giải',
    '3v3 Hỗn Chiến',
    '1v1 Solo',
  ];

  static const List<String> _lienQuanRanks = [
    'Không hiển thị',
    'Đồng',
    'Bạc',
    'Vàng',
    'Bạch Kim',
    'Kim Cương',
    'Tinh Anh',
    'Cao Thủ',
    'Chiến Tướng',
    'Thách Đấu',
  ];

  static const List<String> _robloxModes = [
    'Public Server',
    'Private Server',
    'Đang cày cấp',
    'PvP Arena',
    'Co-op Squad',
    'AFK Farm',
  ];

  static const List<Map<String, String>> _quickRobloxGames = [
    {'name': 'Blox Fruits', 'placeId': '2753915549'},
    {'name': 'Fisch', 'placeId': '16732694052'},
    {'name': 'DOORS', 'placeId': '6516141723'},
    {'name': 'Brookhaven RP', 'placeId': '4924922222'},
    {'name': 'Arsenal', 'placeId': '286090429'},
    {'name': 'BedWars', 'placeId': '6872265039'},
  ];

  static const List<Map<String, String>> _quickOtherGames = [
    {
      'name': 'League of Legends',
      'details': '5v5 Xếp Hạng Đơn/Đôi • Cao Thủ',
      'state': 'Summoner Rift • Yasuo • 12/3/7',
      'img':
          'https://cdn.discordapp.com/app-icons/401518684763586560/5731a6063f6768107519c97b044f58f4.png'
    },
    {
      'name': 'Counter-Strike 2',
      'details': '5v5 Premier Mode • 22,500 ELO',
      'state': 'Mirage • 11 - 9 • 24/14',
      'img':
          'https://cdn.discordapp.com/app-icons/1158805509792092221/8f68f7822303923e8a71602c1b7e7f93.png'
    },
    {
      'name': 'Minecraft',
      'details': 'Survival Multiplayer',
      'state': 'Server DuyVel Network',
      'img':
          'https://cdn.discordapp.com/app-icons/382624125287399424/7123c6278052041990f49b5a6945420b.png'
    },
    {
      'name': 'PUBG Mobile',
      'details': 'Squad 4v4 Xếp Hạng • Chí Tôn',
      'state': 'Erangel • 18 Alive • 9 Kills',
      'img':
          'https://cdn.discordapp.com/app-icons/451550535720501248/1f0795f62856202705a5c62739a00044.png'
    },
    {
      'name': 'Genshin Impact',
      'details': 'AR 60 • La Hoàn Thâm Cảnh',
      'state': 'Tầng 12 Phòng 3',
      'img':
          'https://cdn.discordapp.com/app-icons/762434991303950386/eb0e25b739e4fa38c1671a3d1edcd1e0.png'
    },
  ];

  static const String _lienQuanIconUrl =
      'https://play-lh.googleusercontent.com/6n5c3G6bJ9bP3p9u1C4E7H4rP8nJ7n6P2X1r8u4rT5xM8G0H9w9qY0=s512';

  static const List<String> _musicPlatforms = [
    'Spotify',
    'SoundCloud',
    'YouTube Music',
    'Apple Music',
    'Zing MP3',
  ];

  AccountRpcProfile? get _selectedAccount {
    if (_accounts.isEmpty) return null;
    if (_selectedAccIndex < 0 || _selectedAccIndex >= _accounts.length) {
      _selectedAccIndex = 0;
    }
    return _accounts[_selectedAccIndex];
  }

  @override
  void initState() {
    super.initState();
    _manager = MultiAccountManager(
      onLog: (entry) {
        if (!mounted) return;
        setState(() {
          _logs.insert(0, entry);
          if (_logs.length > 300) _logs.removeLast();
        });
      },
      onUpdate: () {
        if (!mounted) return;
        setState(() {});
      },
      getAccounts: () => _accounts,
    );
    _manager.startAutoMusicSyncLoop();
    _loadSavedAccounts();
    _loadValorantCatalog();
  }

  @override
  void dispose() {
    _manager.dispose();
    _gameNameCtrl.dispose();
    _rrCtrl.dispose();
    _scoreCtrl.dispose();
    _kdaCtrl.dispose();
    _heroCtrl.dispose();
    _mapCtrl.dispose();
    _customDetailsCtrl.dispose();
    _customStateCtrl.dispose();
    _gameBtnLabelCtrl.dispose();
    _gameBtnUrlCtrl.dispose();
    _robloxPlaceCtrl.dispose();
    _musicQueryCtrl.dispose();
    _lastFmCtrl.dispose();
    _musicTitleCtrl.dispose();
    _musicArtistCtrl.dispose();
    _musicAlbumCtrl.dispose();
    _musicDurationCtrl.dispose();
    _musicBtnLabelCtrl.dispose();
    _musicTrackUrlCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadValorantCatalog() async {
    final cat = await ExternalApiService.fetchValorantCatalog();
    if (!mounted) return;
    setState(() => _valCatalog = cat);
  }

  Future<void> _loadSavedAccounts() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(VmVault.s(32));
    if (raw != null && raw.isNotEmpty) {
      try {
        final list = jsonDecode(raw) as List<dynamic>;
        _accounts = list
            .map((e) => AccountRpcProfile.fromJson(e as Map<String, dynamic>))
            .toList();
      } catch (_) {}
    }
    if (_accounts.isNotEmpty) {
      _syncControllersFromSelected();
    }
    if (mounted) setState(() {});
  }

  Future<void> _saveAccounts() async {
    _syncSelectedFromControllers();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      VmVault.s(32),
      jsonEncode(_accounts.map((e) => e.toJson()).toList()),
    );
  }

  void _syncControllersFromSelected() {
    final acc = _selectedAccount;
    if (acc == null) return;
    final g = acc.game;
    final m = acc.music;
    _gameNameCtrl.text = g.gameName;
    _rrCtrl.text = g.rr;
    _scoreCtrl.text = g.score;
    _kdaCtrl.text = g.kda;
    _heroCtrl.text = g.heroOrAgent;
    _mapCtrl.text = g.mapOrServer;
    _customDetailsCtrl.text = g.customDetails;
    _customStateCtrl.text = g.customState;
    _gameBtnLabelCtrl.text = g.buttonLabel;
    _gameBtnUrlCtrl.text = g.buttonUrl;
    _robloxPlaceCtrl.text = g.robloxPlaceId;

    _lastFmCtrl.text = m.lastFmUsername;
    _musicTitleCtrl.text = m.songTitle;
    _musicArtistCtrl.text = m.artistName;
    _musicAlbumCtrl.text = m.albumName;
    _musicDurationCtrl.text = m.durationSeconds.toString();
    _musicBtnLabelCtrl.text = m.buttonLabel;
    _musicTrackUrlCtrl.text = m.trackUrl;
  }

  void _syncSelectedFromControllers() {
    final acc = _selectedAccount;
    if (acc == null) return;
    final g = acc.game;
    final m = acc.music;
    g.gameName = _gameNameCtrl.text.trim();
    g.rr = _rrCtrl.text.trim();
    g.score = _scoreCtrl.text.trim();
    g.kda = _kdaCtrl.text.trim();
    g.heroOrAgent = _heroCtrl.text.trim();
    g.mapOrServer = _mapCtrl.text.trim();
    g.customDetails = _customDetailsCtrl.text.trim();
    g.customState = _customStateCtrl.text.trim();
    g.buttonLabel = _gameBtnLabelCtrl.text.trim();
    g.buttonUrl = _gameBtnUrlCtrl.text.trim();
    g.robloxPlaceId = _robloxPlaceCtrl.text.trim();

    m.lastFmUsername = _lastFmCtrl.text.trim();
    m.songTitle = _musicTitleCtrl.text.trim();
    m.artistName = _musicArtistCtrl.text.trim();
    m.albumName = _musicAlbumCtrl.text.trim();
    m.durationSeconds = int.tryParse(_musicDurationCtrl.text.trim()) ?? 210;
    m.buttonLabel = _musicBtnLabelCtrl.text.trim();
    m.trackUrl = _musicTrackUrlCtrl.text.trim();
  }

  Future<void> _openDiscordServer() async {
    final appUri = Uri.parse(VmVault.s(11));
    final webUri = Uri.parse(VmVault.s(10));
    if (await canLaunchUrl(appUri)) {
      await launchUrl(appUri, mode: LaunchMode.externalApplication);
    } else {
      await launchUrl(webUri, mode: LaunchMode.externalApplication);
    }
  }

  Future<void> _showAddTokenDialog() async {
    final tokensCtrl = TextEditingController();
    final labelCtrl = TextEditingController();
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF0E1322),
        title: const Text('Thêm Token Discord'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: labelCtrl,
              decoration: const InputDecoration(
                labelText: 'Tên gợi nhớ (tùy chọn)',
                hintText: 'vd: Acc Chính',
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: tokensCtrl,
              maxLines: 5,
              decoration: const InputDecoration(
                labelText: 'Nhập 1 hoặc nhiều Token (mỗi dòng 1 token)',
                hintText: 'Token 1\nToken 2\nToken 3...',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Hủy'),
          ),
          FilledButton(
            onPressed: () {
              final lines = tokensCtrl.text
                  .split(RegExp(r'[\r\n]+'))
                  .map((e) => e.trim().replaceAll('"', ''))
                  .where((e) => e.isNotEmpty)
                  .toList();
              if (lines.isNotEmpty) {
                setState(() {
                  for (var i = 0; i < lines.length; i++) {
                    final lbl = labelCtrl.text.trim().isNotEmpty
                        ? (lines.length == 1
                            ? labelCtrl.text.trim()
                            : '${labelCtrl.text.trim()} ${i + 1}')
                        : 'Acc ${_accounts.length + 1}';
                    _accounts.add(AccountRpcProfile(
                      id: '${DateTime.now().microsecondsSinceEpoch}_$i',
                      token: lines[i],
                      label: lbl,
                    ));
                  }
                  _selectedAccIndex = _accounts.length - 1;
                  _syncControllersFromSelected();
                });
                _saveAccounts();
              }
              Navigator.pop(ctx);
            },
            child: const Text('Thêm'),
          ),
        ],
      ),
    );
  }

  Future<void> _applySelectedPresence() async {
    final acc = _selectedAccount;
    if (acc == null) return;
    await _saveAccounts();
    setState(() {});
    if (_manager.isReady(acc.id)) {
      await _manager.updateAccountPresence(acc);
    } else {
      await _manager.connectAccount(acc);
    }
  }

  void _updateValorantAutoAssets(GameRpcConfig g) {
    final cat = _valCatalog;
    if (cat == null) return;
    final mapImg = cat.maps[g.mapOrServer];
    if (mapImg != null && mapImg.isNotEmpty) {
      g.largeImageUrl = mapImg;
      g.largeImageText = '${g.mapOrServer} - VALORANT';
    }
    final agentImg = cat.agents[g.heroOrAgent];
    final rankImg = cat.ranks[g.rank];
    if (rankImg != null && rankImg.isNotEmpty) {
      g.smallImageUrl = rankImg;
      g.smallImageText =
          '${g.rank}${g.rr.isNotEmpty ? " (${g.rr} RR)" : ""} • ${g.heroOrAgent}';
    } else if (agentImg != null && agentImg.isNotEmpty) {
      g.smallImageUrl = agentImg;
      g.smallImageText = g.heroOrAgent;
    }
  }

  void _selectGamePreset(GamePresetType type) {
    final acc = _selectedAccount;
    if (acc == null) return;
    setState(() {
      final g = acc.game;
      g.preset = type;
      if (type == GamePresetType.valorant) {
        g.gameName = 'VALORANT';
        g.mode = _valorantModes.first;
        g.rank = 'Immortal 2';
        g.rr = '78';
        g.heroOrAgent = 'Jett';
        g.mapOrServer = 'Ascent';
        g.score = '10 - 7';
        g.kda = '18/9/4';
        g.partyCurrent = 5;
        g.partyMax = 5;
        g.useParty = true;
        _updateValorantAutoAssets(g);
      } else if (type == GamePresetType.lienQuan) {
        g.gameName = 'Liên Quân Mobile';
        g.mode = _lienQuanModes.first;
        g.rank = 'Chiến Tướng';
        g.heroOrAgent = 'Florentino';
        g.kda = '11/1/6';
        g.customState = 'Trong trận';
        g.partyCurrent = 5;
        g.partyMax = 5;
        g.useParty = true;
        g.largeImageUrl = _lienQuanIconUrl;
        g.largeImageText = 'Liên Quân Mobile';
        g.smallImageUrl = '';
      } else if (type == GamePresetType.roblox) {
        g.gameName = 'Blox Fruits';
        g.robloxPlaceId = '2753915549';
        g.mode = _robloxModes.first;
        g.mapOrServer = 'Sea 3';
        g.customState = '';
        g.partyCurrent = 1;
        g.partyMax = 12;
        g.useParty = true;
        g.smallImageUrl = '';
      } else {
        final first = _quickOtherGames.first;
        g.gameName = first['name']!;
        g.customDetails = first['details']!;
        g.customState = first['state']!;
        g.largeImageUrl = first['img']!;
        g.largeImageText = first['name']!;
        g.smallImageUrl = '';
        g.partyCurrent = 5;
        g.partyMax = 5;
        g.useParty = true;
      }
      _syncControllersFromSelected();
    });
    if (type == GamePresetType.roblox) {
      _fetchRobloxInfo();
    }
  }

  Future<void> _fetchRobloxInfo() async {
    final acc = _selectedAccount;
    if (acc == null) return;
    final pid = _robloxPlaceCtrl.text.trim();
    if (pid.isEmpty) return;
    setState(() => _fetchingRoblox = true);
    final info = await ExternalApiService.fetchRobloxGameByPlaceId(pid);
    if (!mounted) return;
    setState(() {
      _fetchingRoblox = false;
      if (info != null) {
        _gameNameCtrl.text = info.name;
        acc.game.gameName = info.name;
        acc.game.largeImageText = '${info.name} by ${info.creator}';
        if (info.iconUrl.isNotEmpty) {
          acc.game.largeImageUrl = info.iconUrl;
        }
      }
    });
    if (info != null) {
      await _saveAccounts();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Đã tự lấy ảnh & tên game: ${info.name}')),
      );
    }
  }

  Future<void> _fetchOrSearchMusic() async {
    final acc = _selectedAccount;
    if (acc == null) return;
    final q = _musicQueryCtrl.text.trim();
    if (q.isEmpty) return;
    setState(() => _fetchingMusic = true);
    final info = q.startsWith('http')
        ? await ExternalApiService.fetchMusicOEmbed(q)
        : await ExternalApiService.searchMusicTrack(q);
    if (!mounted) return;
    setState(() {
      _fetchingMusic = false;
      if (info != null) {
        acc.music.platformName = info.platform;
        acc.music.songTitle = info.title;
        acc.music.artistName = info.artist;
        acc.music.albumName = info.album;
        acc.music.durationSeconds = info.durationSeconds;
        acc.music.coverImageUrl = info.thumbnailUrl;
        acc.music.trackUrl = info.trackUrl;
        _syncControllersFromSelected();
      }
    });
    if (info != null) {
      await _saveAccounts();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text('Đã lấy ảnh & bài hát: ${info.title} - ${info.artist}')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Không tìm thấy bài hát này')),
      );
    }
  }

  Future<void> _syncSpotifyNowOnce() async {
    final acc = _selectedAccount;
    if (acc == null) return;
    setState(() => _fetchingMusic = true);
    MusicTrackInfo? info;
    if (_lastFmCtrl.text.trim().isNotEmpty) {
      info = await ExternalApiService.fetchLastFmNowPlaying(
          _lastFmCtrl.text.trim());
    } else if (Platform.isWindows) {
      info = await ExternalApiService.detectWindowsSpotifyTrack();
    }
    if (!mounted) return;
    setState(() {
      _fetchingMusic = false;
      if (info != null) {
        acc.music.platformName = info.platform;
        acc.music.songTitle = info.title;
        acc.music.artistName = info.artist;
        acc.music.albumName = info.album;
        acc.music.durationSeconds = info.durationSeconds;
        if (info.thumbnailUrl.isNotEmpty) {
          acc.music.coverImageUrl = info.thumbnailUrl;
        }
        acc.music.trackUrl = info.trackUrl;
        _syncControllersFromSelected();
      }
    });
    if (info != null) {
      await _applySelectedPresence();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Đang nghe Spotify: ${info.title}')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text(
                'Chưa phát hiện bài hát đang phát (mở Spotify trên PC hoặc nhập Last.fm)')),
      );
    }
  }

  Widget _buildAppIcon({double size = 36}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(size * 0.28),
      child: Image.asset(
        'assets/icon.png',
        width: size,
        height: size,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(
          width: size,
          height: size,
          color: const Color(0xFF1A2036),
          alignment: Alignment.center,
          child: Text(
            'DV',
            style: TextStyle(
              fontWeight: FontWeight.w800,
              fontSize: size * 0.4,
              color: const Color(0xFF93A8FF),
            ),
          ),
        ),
      ),
    );
  }

  Widget _card({required Widget child, bool highlighted = false}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0E1322).withAlpha(232),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color:
              highlighted ? const Color(0xFF5865F2) : const Color(0xFF1F2740),
          width: highlighted ? 1.5 : 1,
        ),
      ),
      child: child,
    );
  }

  Widget _buildAccountSelectorBar() {
    if (_accounts.isEmpty) return const SizedBox.shrink();
    return Container(
      height: 46,
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: _accounts.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, i) {
          final acc = _accounts[i];
          final user = _manager.userProfiles[acc.id];
          final online = _manager.isReady(acc.id);
          final selected = i == _selectedAccIndex;
          final title = user?.username ??
              (acc.label.isNotEmpty ? acc.label : 'Acc ${i + 1}');
          return ChoiceChip(
            selected: selected,
            avatar: CircleAvatar(
              radius: 6,
              backgroundColor:
                  online ? const Color(0xFF23A55A) : const Color(0xFF64748B),
            ),
            label: Text(title),
            onSelected: (_) {
              _saveAccounts();
              setState(() {
                _selectedAccIndex = i;
                _syncControllersFromSelected();
              });
            },
          );
        },
      ),
    );
  }

  Widget _buildAccountsTab() {
    final onlineCount =
        _accounts.where((a) => _manager.isReady(a.id)).length;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  _buildAppIcon(size: 44),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'DuyVel Multi-Token RPC',
                          style: TextStyle(
                              fontSize: 17, fontWeight: FontWeight.w800),
                        ),
                        Text(
                          'Online: $onlineCount / ${_accounts.length} • VM Shield Active',
                          style: const TextStyle(
                              fontSize: 12, color: Color(0xFF8E9BBF)),
                        ),
                      ],
                    ),
                  ),
                  FilledButton.icon(
                    onPressed: _openDiscordServer,
                    style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFF5865F2),
                    ),
                    icon: const Icon(Icons.discord, size: 18),
                    label: const Text('hxmoon'),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: _showAddTokenDialog,
                      icon: const Icon(Icons.add),
                      label: const Text('Thêm Token'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: FilledButton(
                      onPressed: _accounts.isEmpty
                          ? null
                          : () => _manager.connectAll(_accounts),
                      style: FilledButton.styleFrom(
                        backgroundColor: const Color(0xFF23A55A),
                      ),
                      child: const Text('Bật tất cả'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _accounts.isEmpty
                          ? null
                          : () => _manager.disconnectAll(),
                      child: const Text('Tắt tất cả'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        if (_accounts.isEmpty)
          _card(
            child: const Padding(
              padding: EdgeInsets.symmetric(vertical: 28),
              child: Center(
                child: Text(
                  'Chưa có tài khoản nào. Bấm "Thêm Token" để log 1 hoặc nhiều acc cùng lúc.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Color(0xFF8E9BBF)),
                ),
              ),
            ),
          ),
        for (var i = 0; i < _accounts.length; i++) _buildAccountItem(i),
      ],
    );
  }

  Widget _buildAccountItem(int index) {
    final acc = _accounts[index];
    final user = _manager.userProfiles[acc.id];
    final connected = _manager.isConnected(acc.id);
    final ready = _manager.isReady(acc.id);
    final selected = index == _selectedAccIndex;

    return GestureDetector(
      onTap: () {
        _saveAccounts();
        setState(() {
          _selectedAccIndex = index;
          _syncControllersFromSelected();
        });
      },
      child: _card(
        highlighted: selected,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 21,
                  backgroundColor: const Color(0xFF1F2740),
                  backgroundImage:
                      user != null ? NetworkImage(user.avatarUrl) : null,
                  child: user == null
                      ? const Icon(Icons.person, color: Colors.white70)
                      : null,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        user != null
                            ? '${user.globalName} (@${user.username})'
                            : (acc.label.isNotEmpty
                                ? acc.label
                                : 'Tài khoản ${index + 1}'),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontWeight: FontWeight.w700, fontSize: 14),
                      ),
                      Text(
                        ready
                            ? 'Online • ${acc.game.enabled ? acc.game.resolvedName() : "No Game"} + ${acc.music.enabled ? acc.music.songTitle : "No Music"}'
                            : (connected
                                ? 'Đang kết nối Gateway...'
                                : 'Đang tắt • Bấm chọn để chỉnh RPC riêng'),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 11,
                          color: ready
                              ? const Color(0xFF4ADE80)
                              : const Color(0xFF8E9BBF),
                        ),
                      ),
                    ],
                  ),
                ),
                Switch(
                  value: connected,
                  onChanged: (v) async {
                    if (v) {
                      await _manager.connectAccount(acc);
                    } else {
                      await _manager.disconnectAccount(acc.id);
                    }
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.delete_outline,
                      color: Color(0xFFF87171), size: 20),
                  onPressed: () async {
                    await _manager.removeAccount(acc.id);
                    setState(() {
                      _accounts.removeAt(index);
                      if (_selectedAccIndex >= _accounts.length) {
                        _selectedAccIndex =
                            _accounts.isEmpty ? 0 : _accounts.length - 1;
                      }
                      _syncControllersFromSelected();
                    });
                    await _saveAccounts();
                  },
                ),
              ],
            ),
            if (selected) ...[
              const Divider(height: 18, color: Color(0xFF1F2740)),
              Row(
                children: [
                  Expanded(
                    child: DropdownButtonFormField<String>(
                      value: acc.status,
                      decoration: const InputDecoration(
                        labelText: 'Trạng thái acc này',
                        isDense: true,
                      ),
                      items: const [
                        DropdownMenuItem(value: 'online', child: Text('Online')),
                        DropdownMenuItem(value: 'idle', child: Text('Idle')),
                        DropdownMenuItem(value: 'dnd', child: Text('DND')),
                      ],
                      onChanged: (v) {
                        if (v != null) {
                          setState(() => acc.status = v);
                          _applySelectedPresence();
                        }
                      },
                    ),
                  ),
                  const SizedBox(width: 8),
                  FilledButton.tonal(
                    onPressed: () => setState(() => _navIndex = 1),
                    child: const Text('Chỉnh Game'),
                  ),
                  const SizedBox(width: 6),
                  FilledButton.tonal(
                    onPressed: () => setState(() => _navIndex = 2),
                    child: const Text('Chỉnh Nhạc'),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildDualPreview(AccountRpcProfile acc) {
    final g = acc.game;
    final m = acc.music;
    return _card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Xem trước 2 thẻ RPC riêng trên Discord',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: Color(0xFF94A3C8),
            ),
          ),
          const SizedBox(height: 10),
          if (g.enabled)
            _previewActivityCard(
              header: 'PLAYING A GAME',
              title: g.resolvedName(),
              details: g.resolvedDetails(),
              state: g.useParty && g.partyMax > 0
                  ? '${g.resolvedState()} (${g.partyCurrent} of ${g.partyMax})'
                  : g.resolvedState(),
              largeImg: g.largeImageUrl,
              smallImg: g.smallImageUrl,
              buttonText: g.showButton ? g.buttonLabel : '',
              isMusic: false,
            ),
          if (g.enabled && m.enabled) const SizedBox(height: 10),
          if (m.enabled)
            _previewActivityCard(
              header: 'LISTENING TO ${m.platformName.toUpperCase()}',
              title: m.songTitle,
              details: 'by ${m.artistName}',
              state: m.albumName.isNotEmpty ? 'on ${m.albumName}' : '',
              largeImg: m.coverImageUrl,
              smallImg: '',
              buttonText: m.showButton ? m.buttonLabel : '',
              isMusic: true,
              showBar: m.showProgressBar,
            ),
        ],
      ),
    );
  }

  Widget _previewActivityCard({
    required String header,
    required String title,
    required String details,
    required String state,
    required String largeImg,
    required String smallImg,
    required String buttonText,
    required bool isMusic,
    bool showBar = false,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF090C16),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF1E253D)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            header,
            style: const TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.7,
              color: Color(0xFF94A3C8),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              SizedBox(
                width: 64,
                height: 64,
                child: Stack(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: Container(
                        width: 60,
                        height: 60,
                        color: const Color(0xFF182038),
                        child: largeImg.startsWith('http')
                            ? Image.network(
                                largeImg,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => Icon(
                                  isMusic
                                      ? Icons.music_note
                                      : Icons.sports_esports,
                                  color: Colors.white54,
                                ),
                              )
                            : Icon(
                                isMusic
                                    ? Icons.music_note
                                    : Icons.sports_esports,
                                color: Colors.white54,
                              ),
                      ),
                    ),
                    if (smallImg.startsWith('http'))
                      Positioned(
                        right: 0,
                        bottom: 0,
                        child: Container(
                          width: 24,
                          height: 24,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: const Color(0xFF090C16),
                            border: Border.all(
                              color: const Color(0xFF090C16),
                              width: 2,
                            ),
                          ),
                          child: ClipOval(
                            child: Image.network(
                              smallImg,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) =>
                                  const SizedBox.shrink(),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                      ),
                    ),
                    if (details.isNotEmpty)
                      Text(
                        details,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 12,
                          color: Color(0xFFC4CEE8),
                        ),
                      ),
                    if (state.isNotEmpty)
                      Text(
                        state,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 11,
                          color: Color(0xFF8E9BBF),
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
          if (isMusic && showBar) ...[
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: const LinearProgressIndicator(
                value: 0.45,
                minHeight: 4,
                backgroundColor: Color(0xFF232B45),
                valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF1DB954)),
              ),
            ),
          ],
          if (buttonText.isNotEmpty) ...[
            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 6),
              decoration: BoxDecoration(
                color: const Color(0xFF1D243B),
                borderRadius: BorderRadius.circular(6),
              ),
              alignment: Alignment.center,
              child: Text(
                buttonText,
                style:
                    const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildGameTab() {
    final acc = _selectedAccount;
    if (acc == null) {
      return const Center(
        child: Text('Hãy thêm ít nhất 1 Token ở tab Tài khoản trước.'),
      );
    }
    _syncSelectedFromControllers();
    final g = acc.game;

    return Column(
      children: [
        _buildAccountSelectorBar(),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _buildDualPreview(acc),
              _card(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Game RPC (Tự động lấy ảnh game)',
                          style: TextStyle(
                              fontSize: 15, fontWeight: FontWeight.w700),
                        ),
                        Switch(
                          value: g.enabled,
                          onChanged: (v) => setState(() => g.enabled = v),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        ChoiceChip(
                          label: const Text('VALORANT Tracker'),
                          selected: g.preset == GamePresetType.valorant,
                          onSelected: (_) =>
                              _selectGamePreset(GamePresetType.valorant),
                        ),
                        ChoiceChip(
                          label: const Text('Liên Quân'),
                          selected: g.preset == GamePresetType.lienQuan,
                          onSelected: (_) =>
                              _selectGamePreset(GamePresetType.lienQuan),
                        ),
                        ChoiceChip(
                          label: const Text('Roblox'),
                          selected: g.preset == GamePresetType.roblox,
                          onSelected: (_) =>
                              _selectGamePreset(GamePresetType.roblox),
                        ),
                        ChoiceChip(
                          label: const Text('Game Khác'),
                          selected: g.preset == GamePresetType.other,
                          onSelected: (_) =>
                              _selectGamePreset(GamePresetType.other),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              if (g.preset == GamePresetType.valorant) _buildValorantFields(g),
              if (g.preset == GamePresetType.lienQuan) _buildLienQuanFields(g),
              if (g.preset == GamePresetType.roblox) _buildRobloxFields(g),
              if (g.preset == GamePresetType.other) _buildOtherGameFields(g),
              _card(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Hiển thị Party (vd: 5 of 5)'),
                      value: g.useParty,
                      onChanged: (v) => setState(() => g.useParty = v),
                    ),
                    if (g.useParty)
                      Row(
                        children: [
                          Expanded(
                            child: DropdownButtonFormField<int>(
                              value: g.partyCurrent.clamp(1, 12),
                              decoration:
                                  const InputDecoration(labelText: 'Hiện tại'),
                              items: List.generate(
                                12,
                                (i) => DropdownMenuItem(
                                    value: i + 1, child: Text('${i + 1}')),
                              ),
                              onChanged: (v) {
                                if (v != null) {
                                  setState(() => g.partyCurrent = v);
                                }
                              },
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: DropdownButtonFormField<int>(
                              value: g.partyMax.clamp(1, 12),
                              decoration:
                                  const InputDecoration(labelText: 'Tối đa'),
                              items: List.generate(
                                12,
                                (i) => DropdownMenuItem(
                                    value: i + 1, child: Text('${i + 1}')),
                              ),
                              onChanged: (v) {
                                if (v != null) setState(() => g.partyMax = v);
                              },
                            ),
                          ),
                        ],
                      ),
                    const SizedBox(height: 8),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Hiển thị nút bấm dưới RPC Game'),
                      value: g.showButton,
                      onChanged: (v) => setState(() => g.showButton = v),
                    ),
                    if (g.showButton) ...[
                      TextField(
                        controller: _gameBtnLabelCtrl,
                        decoration:
                            const InputDecoration(labelText: 'Tên nút bấm'),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: _gameBtnUrlCtrl,
                        decoration:
                            const InputDecoration(labelText: 'Link nút bấm'),
                      ),
                    ],
                    const SizedBox(height: 14),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: _applySelectedPresence,
                        icon: const Icon(Icons.check),
                        label: const Text('Cập nhật RPC cho acc này'),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildValorantFields(GameRpcConfig g) {
    final mapList = (_valCatalog?.maps.keys.toList() ??
            ['Ascent', 'Bind', 'Haven', 'Split', 'Lotus'])
      ..sort();
    final agentList = (_valCatalog?.agents.keys.toList() ??
            ['Jett', 'Reyna', 'Clove', 'Omen', 'Iso'])
      ..sort();
    final rankList = _valCatalog?.ranks.keys.toList() ??
        [
          'Unranked',
          'Iron 3',
          'Bronze 3',
          'Silver 3',
          'Gold 3',
          'Platinum 3',
          'Diamond 3',
          'Ascendant 3',
          'Immortal 2',
          'Radiant',
        ];

    final safeMode =
        _valorantModes.contains(g.mode) ? g.mode : _valorantModes.first;
    final safeMap =
        mapList.contains(g.mapOrServer) ? g.mapOrServer : mapList.first;
    final safeAgent =
        agentList.contains(g.heroOrAgent) ? g.heroOrAgent : agentList.first;
    final safeRank = rankList.contains(g.rank) ? g.rank : rankList.first;

    return _card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'VALORANT Tracker.gg Style (Tự lấy ảnh Map & Rank)',
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: safeMode,
            decoration: const InputDecoration(labelText: 'Chế độ chơi'),
            items: _valorantModes
                .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                .toList(),
            onChanged: (v) {
              if (v != null) setState(() => g.mode = v);
            },
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                flex: 2,
                child: DropdownButtonFormField<String>(
                  value: safeRank,
                  decoration: const InputDecoration(labelText: 'Rank'),
                  items: rankList
                      .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                      .toList(),
                  onChanged: (v) {
                    if (v != null) {
                      setState(() {
                        g.rank = v;
                        _updateValorantAutoAssets(g);
                      });
                    }
                  },
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: TextField(
                  controller: _rrCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'RR'),
                  onChanged: (_) => setState(() {}),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: DropdownButtonFormField<String>(
                  value: safeMap,
                  decoration: const InputDecoration(labelText: 'Map (Ảnh lớn)'),
                  items: mapList
                      .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                      .toList(),
                  onChanged: (v) {
                    if (v != null) {
                      setState(() {
                        g.mapOrServer = v;
                        _mapCtrl.text = v;
                        _updateValorantAutoAssets(g);
                      });
                    }
                  },
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: DropdownButtonFormField<String>(
                  value: safeAgent,
                  decoration: const InputDecoration(labelText: 'Agent'),
                  items: agentList
                      .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                      .toList(),
                  onChanged: (v) {
                    if (v != null) {
                      setState(() {
                        g.heroOrAgent = v;
                        _heroCtrl.text = v;
                        _updateValorantAutoAssets(g);
                      });
                    }
                  },
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _scoreCtrl,
                  decoration:
                      const InputDecoration(labelText: 'Tỉ số (vd: 10 - 7)'),
                  onChanged: (_) => setState(() {}),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: TextField(
                  controller: _kdaCtrl,
                  decoration:
                      const InputDecoration(labelText: 'K/D/A (vd: 18/9/4)'),
                  onChanged: (_) => setState(() {}),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildLienQuanFields(GameRpcConfig g) {
    final safeMode =
        _lienQuanModes.contains(g.mode) ? g.mode : _lienQuanModes.first;
    final safeRank =
        _lienQuanRanks.contains(g.rank) ? g.rank : _lienQuanRanks.first;
    return _card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Liên Quân Mobile',
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: safeMode,
            decoration: const InputDecoration(labelText: 'Chế độ đấu'),
            items: _lienQuanModes
                .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                .toList(),
            onChanged: (v) {
              if (v != null) setState(() => g.mode = v);
            },
          ),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            value: safeRank,
            decoration: const InputDecoration(labelText: 'Bậc Rank'),
            items: _lienQuanRanks
                .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                .toList(),
            onChanged: (v) {
              if (v != null) setState(() => g.rank = v);
            },
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _heroCtrl,
            decoration: const InputDecoration(labelText: 'Tướng đang chơi'),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _kdaCtrl,
            decoration: const InputDecoration(labelText: 'K/D/A (vd: 11/1/6)'),
            onChanged: (_) => setState(() {}),
          ),
        ],
      ),
    );
  }

  Widget _buildRobloxFields(GameRpcConfig g) {
    final safeMode =
        _robloxModes.contains(g.mode) ? g.mode : _robloxModes.first;
    return _card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Roblox (Tự lấy ảnh & tên game từ Place ID)',
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: _quickRobloxGames.map((item) {
              return ActionChip(
                label: Text(item['name']!),
                onPressed: () {
                  setState(() {
                    _gameNameCtrl.text = item['name']!;
                    _robloxPlaceCtrl.text = item['placeId']!;
                  });
                  _fetchRobloxInfo();
                },
              );
            }).toList(),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _robloxPlaceCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Roblox Place ID',
                    hintText: 'vd: 2753915549',
                  ),
                ),
              ),
              const SizedBox(width: 8),
              FilledButton(
                onPressed: _fetchingRoblox ? null : _fetchRobloxInfo,
                child: Text(_fetchingRoblox ? 'Đang tải...' : 'Lấy Game'),
              ),
            ],
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _gameNameCtrl,
            decoration: const InputDecoration(labelText: 'Tên Game Roblox'),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 8),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Dùng tên game làm tiêu đề chính'),
            value: g.robloxUseGameTitleAsActivityName,
            onChanged: (v) =>
                setState(() => g.robloxUseGameTitleAsActivityName = v),
          ),
          DropdownButtonFormField<String>(
            value: safeMode,
            decoration: const InputDecoration(labelText: 'Server / Chế độ'),
            items: _robloxModes
                .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                .toList(),
            onChanged: (v) {
              if (v != null) setState(() => g.mode = v);
            },
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _mapCtrl,
            decoration:
                const InputDecoration(labelText: 'Khu vực (vd: Sea 3, Floor 2)'),
            onChanged: (_) => setState(() {}),
          ),
        ],
      ),
    );
  }

  Widget _buildOtherGameFields(GameRpcConfig g) {
    return _card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Các Tựa Game Khác (Tự điền ảnh chính thức)',
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: _quickOtherGames.map((item) {
              return ActionChip(
                label: Text(item['name']!),
                onPressed: () {
                  setState(() {
                    _gameNameCtrl.text = item['name']!;
                    _customDetailsCtrl.text = item['details']!;
                    _customStateCtrl.text = item['state']!;
                    g.largeImageUrl = item['img']!;
                    g.largeImageText = item['name']!;
                  });
                },
              );
            }).toList(),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _gameNameCtrl,
            decoration: const InputDecoration(labelText: 'Tên Game'),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _customDetailsCtrl,
            decoration:
                const InputDecoration(labelText: 'Dòng 1 (Chế độ, Rank)'),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _customStateCtrl,
            decoration:
                const InputDecoration(labelText: 'Dòng 2 (Map, KDA, Trạng thái)'),
            onChanged: (_) => setState(() {}),
          ),
        ],
      ),
    );
  }

  Widget _buildMusicTab() {
    final acc = _selectedAccount;
    if (acc == null) {
      return const Center(
        child: Text('Hãy thêm ít nhất 1 Token ở tab Tài khoản trước.'),
      );
    }
    _syncSelectedFromControllers();
    final m = acc.music;
    final safePlatform = _musicPlatforms.contains(m.platformName)
        ? m.platformName
        : _musicPlatforms.first;

    return Column(
      children: [
        _buildAccountSelectorBar(),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _buildDualPreview(acc),
              _card(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Spotify / Music Auto-Sync',
                          style: TextStyle(
                              fontSize: 15, fontWeight: FontWeight.w700),
                        ),
                        Switch(
                          value: m.enabled,
                          onChanged: (v) => setState(() => m.enabled = v),
                        ),
                      ],
                    ),
                    if (Platform.isWindows)
                      SwitchListTile(
                        contentPadding: EdgeInsets.zero,
                        title: const Text(
                            'Tự động bắt bài hát Spotify đang mở trên PC'),
                        subtitle: const Text(
                          'Tự lấy ảnh bìa, tên bài hát, ca sĩ và thời lượng',
                          style: TextStyle(fontSize: 11),
                        ),
                        value: m.autoSyncPcSpotify,
                        onChanged: (v) =>
                            setState(() => m.autoSyncPcSpotify = v),
                      ),
                    TextField(
                      controller: _lastFmCtrl,
                      decoration: const InputDecoration(
                        labelText:
                            'Last.fm Username (Auto-Sync Spotify trên Mobile/iOS/PC)',
                        hintText: 'Liên kết Spotify -> Last.fm để tự bắt nhạc',
                      ),
                    ),
                    const SizedBox(height: 10),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: _fetchingMusic ? null : _syncSpotifyNowOnce,
                        icon: const Icon(Icons.radar),
                        label: Text(_fetchingMusic
                            ? 'Đang quét nhạc...'
                            : 'Quét bài hát Spotify đang nghe ngay'),
                      ),
                    ),
                    const Divider(height: 24, color: Color(0xFF1F2740)),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _musicQueryCtrl,
                            decoration: const InputDecoration(
                              labelText:
                                  'Tìm tên bài hát hoặc dán link Spotify/SC',
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        FilledButton(
                          onPressed:
                              _fetchingMusic ? null : _fetchOrSearchMusic,
                          child: Text(_fetchingMusic ? '...' : 'Tự lấy'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      value: safePlatform,
                      decoration:
                          const InputDecoration(labelText: 'Nền tảng nhạc'),
                      items: _musicPlatforms
                          .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                          .toList(),
                      onChanged: (v) {
                        if (v != null) setState(() => m.platformName = v);
                      },
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: _musicTitleCtrl,
                      decoration:
                          const InputDecoration(labelText: 'Tên bài hát'),
                      onChanged: (_) => setState(() {}),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: _musicArtistCtrl,
                      decoration:
                          const InputDecoration(labelText: 'Ca sĩ / Nghệ sĩ'),
                      onChanged: (_) => setState(() {}),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: _musicAlbumCtrl,
                      decoration: const InputDecoration(labelText: 'Album'),
                      onChanged: (_) => setState(() {}),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _musicDurationCtrl,
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(
                                labelText: 'Thời lượng (giây)'),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: SwitchListTile(
                            contentPadding: EdgeInsets.zero,
                            title: const Text('Thanh thời gian',
                                style: TextStyle(fontSize: 13)),
                            value: m.showProgressBar,
                            onChanged: (v) =>
                                setState(() => m.showProgressBar = v),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Hiển thị nút bấm dưới RPC Nhạc'),
                      value: m.showButton,
                      onChanged: (v) => setState(() => m.showButton = v),
                    ),
                    if (m.showButton) ...[
                      TextField(
                        controller: _musicBtnLabelCtrl,
                        decoration:
                            const InputDecoration(labelText: 'Tên nút bấm'),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: _musicTrackUrlCtrl,
                        decoration:
                            const InputDecoration(labelText: 'Link bài hát'),
                      ),
                    ],
                    const SizedBox(height: 14),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: _applySelectedPresence,
                        icon: const Icon(Icons.music_note),
                        label: const Text('Cập nhật Nhạc cho acc này'),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildLogsTab() {
    Color levelColor(int lvl) {
      if (lvl == 3) return const Color(0xFF4ADE80);
      if (lvl == 2) return const Color(0xFFF87171);
      if (lvl == 1) return const Color(0xFFFACC15);
      return const Color(0xFF60A5FA);
    }

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Multi-Account Gateway Logs',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
              ),
              TextButton(
                onPressed: () => setState(() => _logs.clear()),
                child: const Text('Xóa log'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Expanded(
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFF05070D),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFF1D243C)),
              ),
              child: _logs.isEmpty
                  ? const Center(
                      child: Text(
                        '[SYSTEM] Chưa có log kết nối',
                        style: TextStyle(
                          fontFamily: 'monospace',
                          color: Color(0xFF64748B),
                        ),
                      ),
                    )
                  : ListView.builder(
                      itemCount: _logs.length,
                      itemBuilder: (context, i) {
                        final e = _logs[i];
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 3),
                          child: RichText(
                            text: TextSpan(
                              style: const TextStyle(
                                fontFamily: 'monospace',
                                fontSize: 12,
                              ),
                              children: [
                                TextSpan(
                                  text: '[${e.timestamp}] ',
                                  style:
                                      const TextStyle(color: Color(0xFF64748B)),
                                ),
                                TextSpan(
                                  text: '[${e.accountTag}] ',
                                  style: const TextStyle(
                                    color: Color(0xFFA78BFA),
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                TextSpan(
                                  text: '[${e.tag}] ',
                                  style: TextStyle(
                                    color: levelColor(e.level),
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                TextSpan(
                                  text: e.message,
                                  style:
                                      const TextStyle(color: Color(0xFFE2E8F0)),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _buildAccountsTab(),
      _buildGameTab(),
      _buildMusicTab(),
      _buildLogsTab(),
    ];

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF090D19),
        title: Row(
          children: [
            _buildAppIcon(size: 30),
            const SizedBox(width: 10),
            Text(
              VmVault.s(28),
              style: const TextStyle(fontWeight: FontWeight.w800),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Mở Discord hxmoon',
            onPressed: _openDiscordServer,
            icon: const Icon(Icons.discord, color: Color(0xFF7289DA)),
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: GalaxyBackground(
        child: pages[_navIndex],
      ),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF090D19),
        selectedIndex: _navIndex,
        onDestinationSelected: (i) {
          _saveAccounts();
          setState(() => _navIndex = i);
        },
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.group_outlined),
            selectedIcon: Icon(Icons.group),
            label: 'Tài khoản',
          ),
          NavigationDestination(
            icon: Icon(Icons.sports_esports_outlined),
            selectedIcon: Icon(Icons.sports_esports),
            label: 'Game',
          ),
          NavigationDestination(
            icon: Icon(Icons.music_note_outlined),
            selectedIcon: Icon(Icons.music_note),
            label: 'Nhạc',
          ),
          NavigationDestination(
            icon: Icon(Icons.terminal_outlined),
            selectedIcon: Icon(Icons.terminal),
            label: 'Logs',
          ),
        ],
      ),
    );
  }
}
