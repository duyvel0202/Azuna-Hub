import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'vm_vault.dart';

class RuntimeGuard {
  static Timer? _watchdog;
  static bool _compromised = false;

  static bool get isCompromised => _compromised;

  static void engage() {
    if (!kReleaseMode) return;
    _inspectEnvironment();
    _watchdog?.cancel();
    _watchdog = Timer.periodic(const Duration(seconds: 15), (_) {
      _inspectEnvironment();
    });
  }

  static Future<void> _inspectEnvironment() async {
    try {
      if (Platform.isAndroid || Platform.isLinux) {
        final statusFile = File(VmVault.s(46));
        if (await statusFile.exists()) {
          final text = await statusFile.readAsString();
          final marker = VmVault.s(47);
          for (final line in text.split('\n')) {
            if (line.startsWith(marker)) {
              final pidStr = line.substring(marker.length).trim();
              final pid = int.tryParse(pidStr) ?? 0;
              if (pid > 0) {
                _triggerCountermeasure();
                return;
              }
            }
          }
        }
        final mapsFile = File(VmVault.s(45));
        if (await mapsFile.exists()) {
          final maps = (await mapsFile.readAsString()).toLowerCase();
          final sigs = [
            VmVault.s(33),
            VmVault.s(34),
            VmVault.s(35),
            VmVault.s(36),
            VmVault.s(37),
          ];
          for (final sig in sigs) {
            if (sig.isNotEmpty && maps.contains(sig)) {
              _triggerCountermeasure();
              return;
            }
          }
        }
      } else if (Platform.isWindows) {
        final res = await Process.run(
          'tasklist',
          ['/FO', 'CSV', '/NH'],
        ).timeout(const Duration(seconds: 3));
        final out = res.stdout.toString().toLowerCase();
        final badTools = [
          VmVault.s(38),
          VmVault.s(39),
          VmVault.s(40),
          VmVault.s(41),
          VmVault.s(42),
          VmVault.s(43),
          VmVault.s(44),
          VmVault.s(33),
        ];
        for (final tool in badTools) {
          if (tool.isNotEmpty && out.contains(tool)) {
            _triggerCountermeasure();
            return;
          }
        }
      }
    } catch (_) {}
  }

  static void _triggerCountermeasure() {
    _compromised = true;
    VmVault.corrupt();
    exit(0);
  }
}
